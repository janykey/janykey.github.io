/*
 * TestSuiteEvaluation.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.evaluation;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author Jan Hinzmann
 *
 */
public class TestSuiteEvaluation extends TestCase {


    /**
     * This returns the Test for the evaluation package.
     *
     * @return Test the Test for the evaluation package.
     */
    public static Test suite() {
        TestSuite suite = new TestSuite("Evaluation TestSuite");

        suite.addTestSuite(ComparatorTest.class);
        suite.addTestSuite(DifferenceTest.class);

        return suite;
    }

}
