/*
 * TestSuiteEvaluation.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author Jan Hinzmann
 *
 */
public class TestSuiteChecks extends TestCase {


    /**
     * This returns the Test for the evaluation package.
     *
     * @return Test the Test for the evaluation package.
     */
    public static Test suite() {
        TestSuite suite = new TestSuite("Checks TestSuite");

        suite.addTestSuite(CheckTemplateTest.class);
        
        suite.addTestSuite(InterfacesAddedTest.class);
        suite.addTestSuite(InterfacesRemovedTest.class);
        suite.addTestSuite(InterfacesModifiedTest.class);
        
        suite.addTestSuite(MembersAddedTest.class);
        suite.addTestSuite(MembersRemovedTest.class);
        suite.addTestSuite(MembersModifiedTest.class);
        suite.addTestSuite(MembersModifiedUsingComparatorTest.class);
        
        suite.addTestSuite(ParameterAddedTest.class);
        suite.addTestSuite(ParameterRemovedTest.class);
        
        //non elementary checks
        suite.addTestSuite(AddedPublicMethodsInImplementingClassesTest.class);
        suite.addTestSuite(AddedPrivateMembersInClassesTest.class);
        
        return suite;
    }

}
