/*
 * HTMLReporterTest.java
 *
 * <Beschreibung>
 *
 * Created: May 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.report;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import junit.framework.TestCase;

/**
 * @author Jan Hinzmann
 * 
 */
public class HTMLReporterTest extends TestCase {

    /**
     * @param name
     */
    public HTMLReporterTest(String name) {
        super(name);
    }

    /*
     * (non-Javadoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
    }

    public void testTransformation() {

        File xsl, xml, html;

        xsl = new File("src/xsl/modi2html.xsl");
        xml = new File("testdata/xmlReport/modireport.xml");
        html = new File("testdata/xmlReport/modireport.html");

        TransformerFactory transformerFactory = TransformerFactory
                .newInstance();

        Source xslSource = new StreamSource(xsl);
        Source xmlSource = new StreamSource(xml);
        Result outputTarget;
        try {
            outputTarget = new StreamResult(new FileOutputStream(html));
            Transformer transformer;
            transformer = transformerFactory.newTransformer(xslSource);
            transformer.transform(xmlSource, outputTarget);

            assertTrue(html.exists());
            
        } catch (FileNotFoundException e) {
            fail("A File could not be found: " + e.getMessage());
        } catch (TransformerConfigurationException e) {
            fail("A TransformerConfigurationException occurred: " + e.getMessage());
        } catch (TransformerException e) {
            fail("A TransformerException occurred: " + e.getMessage());
        }
    }
}
