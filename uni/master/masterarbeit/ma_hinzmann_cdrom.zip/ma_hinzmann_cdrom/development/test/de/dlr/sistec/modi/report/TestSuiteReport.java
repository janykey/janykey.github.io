/*
 * TestSuiteReport.java
 *
 * <Beschreibung>
 *
 * Created: Mar 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.report;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author Jan Hinzmann
 *
 */
public class TestSuiteReport extends TestCase {

    public static Test suite(){
        TestSuite suite = new TestSuite("Report TestSuite");

        // report
        suite.addTestSuite(ReportTest.class);
        suite.addTestSuite(HTMLReporterTest.class);
        
        return suite;
    }

}
