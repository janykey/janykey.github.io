/*
 * AddedPublicMethodsInImplementingClassesTest.java
 *
 * <Beschreibung>
 *
 * Created: Apr 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.MoDi;
import de.dlr.sistec.modi.checks.impl.AddedPublicMethodsInImplementingClasses;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 * 
 */
public class AddedPublicMethodsInImplementingClassesTest extends TestCase {

    private IMetaRepresentation metarepresenation;
    private IModel architectsModel;
    private IModel developersModel;
    private IModelItem amInterface;
    private IModelItem dmInterface;
    private IModelItem dmClass;
    private ICheck addedPublicMethodsInImplementingClasses;
    
    /**
     * @param name
     */
    public AddedPublicMethodsInImplementingClassesTest(String name) {
        super(name);
    }

    /*
     * (non-Javadoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        
        setUpAM();
        setUpDM();

        addedPublicMethodsInImplementingClasses 
            = new AddedPublicMethodsInImplementingClasses();
                
    }
    
    private void setUpAM() {
        
        amInterface = new ModelItem();
        amInterface.setName("AnInterface");
        amInterface.setType("interface");
        
        IMember amMethod =  new Operation(); 
        amMethod.setName("myMethod");
        amInterface.addMember(amMethod);
        
        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);
        architectsModel.addModelItem(amInterface);
        
        metarepresenation = MetaRepresentation.getInstance();
        metarepresenation.setAmModel(architectsModel);
    }
    
    private void setUpDM() {
        List<String> modifiers = new ArrayList<String>();
        modifiers.add("public");
        //set up an interface
        dmInterface = new ModelItem();
        dmInterface.setName("AnInterface");
        dmInterface.setType("interface");
        
        IMember dmMethod =  new Operation(); 
        dmMethod.setName("myMethod");
        dmInterface.addMember(dmMethod);
        
        //set up a implementing class
        dmClass = new ModelItem();
        dmClass.setName("MyClass");
        dmClass.setType("class");
        dmClass.addExtendee(dmInterface);//MyClass implements AnInterface
        
        IMember dmClassMethod =  new Operation(); 
        dmClassMethod.setName("myMethod");
        dmClass.addMember(dmClassMethod);
        
        //!\ an Xtra public Method in the implementing class.
        IMember anExtraMethod =  new Operation();
        anExtraMethod.setModifiers(modifiers);
        anExtraMethod.setName("extraMethod");
        dmClass.addMember(anExtraMethod);
        
        //putting all together
        developersModel = new Model();
        developersModel.setType(Model.Type.DM);
        developersModel.addModelItem(dmInterface);
        developersModel.addModelItem(dmClass);

        metarepresenation = MetaRepresentation.getInstance();
        metarepresenation.setDmModel(developersModel);
    }

    /**
     * Test method for
     * {@link de.dlr.sistec.modi.checks.impl
     *          .AddedPublicMethodsInImplementingClasses#check(java.util.List)}.
     */
    public void testCheck() {

        List<IDifference> differences 
        = addedPublicMethodsInImplementingClasses.check(null);
        
        assertNotNull("The check method must not return null", differences);

        assertTrue("There must be one Difference", differences.size() == 1);
        
        IDifference difference = differences.get(0);
        assertTrue("The DMElement of the difference must be the one with the" 
                + " added public method in it.",
                difference.getDMElement().equals(dmClass));
    }

    public void testIntegratedCheck() throws Exception {
        MoDi modi = new MoDi();
        String modelRoot = "testdata/addedPublicMethodsInImplementingClasses/";
        
        modi.findArchitectsModelFiles(MoDi.ImportHandler.FILESYSTEM, 
                modelRoot + "am", "java");
        modi.findDevelopersModelFiles(MoDi.ImportHandler.FILESYSTEM, 
                modelRoot + "dm", "java");
        
        modi.transformArchitectsModel(MoDi.Language.JAVA);
        modi.transformDevelopersModel(MoDi.Language.JAVA);
        
        List<IDifference> differences 
        = addedPublicMethodsInImplementingClasses.check(null);
        
        assertNotNull("The check method must not return null", differences);
        
        assertEquals("There must be one Difference", 1, differences.size());
        
        IDifference difference = differences.get(0);
        String expected = "AClass";
        String actual =  difference.getDMElement().getIdentifier();
        assertEquals("The DMElement of the difference must be the one with the" 
                + " added public method in it.", expected, actual);
    }
}
