/*
 * ModiTest.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: MasterTestSuiteMoDi.java 304 2007-05-22 11:23:38Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import de.dlr.sistec.modi.checks.TestSuiteChecks;
import de.dlr.sistec.modi.evaluation.TestSuiteEvaluation;
import de.dlr.sistec.modi.metarepresentation.TestSuiteMetaRepresentation;
import de.dlr.sistec.modi.report.TestSuiteReport;
import de.dlr.sistec.modi.transformation.TestSuiteTransformation;

public class MasterTestSuiteMoDi extends TestCase {


    public static Test suite() {
        TestSuite suite = new TestSuite("MoDi Master TestSuite");

        //checks
        suite.addTest(TestSuiteChecks.suite());
        
        // evaluation
        suite.addTest(TestSuiteEvaluation.suite());

        // metarepresentation
        suite.addTest(TestSuiteMetaRepresentation.suite());

        //report
        suite.addTest(TestSuiteReport.suite());
        
        // transformation
        suite.addTest(TestSuiteTransformation.suite());

        // modi
        suite.addTest(TestSuiteMoDi.suite());
        
        return suite;
    }
}
