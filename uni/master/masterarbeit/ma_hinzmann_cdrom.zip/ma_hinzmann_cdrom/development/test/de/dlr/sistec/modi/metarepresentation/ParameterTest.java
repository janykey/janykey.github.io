/*
 * ParameterTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;

/**
 * @author Jan Hinzmann
 *
 */
public class ParameterTest extends TestCase {

    private Parameter parameter;
    
    /**
     * @param name
     */
    public ParameterTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        parameter = new Parameter();
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Parameter#Parameter()}.
     */
    public void testParameter() {
        assertNotNull(parameter.getIdentifier());
        assertNotNull(parameter.getType());
    }


    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Parameter#setIdentifier(java.lang.String)}.
     */
    public void testGetIdentifier() {
        String expected = "de.dlr.de.IAnInterface.foo.aParameter";
        parameter.setName("aParameter");
        parameter.setNamespace("de.dlr.de.IAnInterface.foo");
        assertEquals(expected, parameter.getIdentifier());
    }


    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Parameter#setType(de.dlr.sistec.modi.metarepresentation.impl
     *          .ModelItem)}.
     */
    public void testSetType() {
        ModelItem newType = new ModelItem();
        parameter.setType(newType);
        assertSame(newType, parameter.getType());
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Parameter#equals(java.lang.Object)}.
     */
    public void testEqualsObject() {
        assertFalse(parameter.equals(null));
        assertTrue(parameter.equals(parameter));
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Parameter#toString()}.
     */
    public void testToString() {
        assertNotNull(parameter.toString());
        assertTrue(parameter.toString() instanceof String);
    }

}
