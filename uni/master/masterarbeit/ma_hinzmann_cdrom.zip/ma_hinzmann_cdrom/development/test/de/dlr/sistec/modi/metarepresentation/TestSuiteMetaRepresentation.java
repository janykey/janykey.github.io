/*
 * MetaRepresentationTestSuite.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * This is a test suite for the metarepresentation.
 *
 * @author Jan Hinzmann
 */
public class TestSuiteMetaRepresentation {


    /**
     * This returns the Test for the MetaRepresentation.
     *
     * @return Test the Test for the MetaRepresentation.
     */
    public static Test suite() {
        TestSuite suite = new TestSuite("Meta Representation TestSuite");

        suite.addTestSuite(MemberTest.class);
        suite.addTestSuite(MetaRepresentationTest.class);
        suite.addTestSuite(ModelTest.class);
        suite.addTestSuite(ModelItemTest.class);
        suite.addTestSuite(OperationTest.class);
        suite.addTestSuite(VariableTest.class);
        suite.addTestSuite(ParameterTest.class);

        return suite;
    }

}
