/*
 * ReportTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.report;

import junit.framework.TestCase;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.report.impl.Report;

/**
 * @author Jan Hinzmann
 *
 */
public class ReportTest extends TestCase {

    private IReport report;
    /**
     * @param name
     */
    public ReportTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        report = new Report();
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.report.impl.Report#Report()}.
     */
    public void testReport() {
        assertNotNull("The differences must not be null", 
                report.getDifferences());
        assertNotNull("The date must not be null", report.getDate());
        assertNotNull("The architect must not be null", report.getArchitect());
        assertNotNull("The architectsModelVersion must not be null",
                report.getArchitectsModelVersion());
        assertNotNull("The developer must not be null", report.getDeveloper());
        assertNotNull("The developersModelVersion must not be null", 
                report.getDevelopersModelVersion());
    }
    
    public void testAddDifference(){
        int sizeBefore = report.getDifferences().size();
        report.add(new Difference());
        int sizeAfter = report.getDifferences().size();
        int expected = sizeBefore + 1;
        assertEquals("before: " + sizeBefore + " after: " + sizeAfter,
                sizeAfter, expected);
        
                
    }
}
