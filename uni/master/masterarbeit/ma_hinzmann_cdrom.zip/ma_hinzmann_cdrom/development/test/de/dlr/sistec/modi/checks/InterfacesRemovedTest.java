/*
 * InterfacesRemoved.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.ModelItemsRemoved;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.impl.Report;

/**
 * Test for the InterfaceRemoved rule.
 * 
 * @author Jan Hinzmann
 */
public class InterfacesRemovedTest extends TestCase {

    private IMetaRepresentation metarepresenation;

    private IModel architectsModel;

    private IModel developersModel;

    private IModelItem amModelItem;

    private ICheck interfacesRemovedCheck;

    /**
     * setUp.
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        metarepresenation = MetaRepresentation.getInstance();
        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);

        developersModel = new Model();
        developersModel.setType(Model.Type.DM);

        amModelItem = new ModelItem();
        amModelItem.setType("interface");
        amModelItem.setName("RemovedInterface");

        architectsModel.addModelItem(amModelItem);

        metarepresenation.setAmModel(architectsModel);
        metarepresenation.setDmModel(developersModel);

        interfacesRemovedCheck = new ModelItemsRemoved();

    }

    /**
     * Test method for evaluate.
     * {@link de.dlr.sistec.modi.evaluation.checks.ModelItemsRemoved#
     * evaluate(java.util.List, java.util.List)}.
     */
    public void testInterfacesRemoved() {
        IReport report = new Report();
        List<IDifference> differencesFound = interfacesRemovedCheck
                .check(report.getDifferences());

        assertNotNull("There should be at least an empty list of differences",
                differencesFound);
        int differences = differencesFound.size();
        assertTrue("There must be 1 difference, found: " + differences,
                differences == 1);

        IDifference.Status expected = IDifference.Status.REMOVED;
        IDifference.Status actual = differencesFound.get(0).getStatus();
        assertEquals("There should be a difference with the status removed.",
                expected, actual);
    }

}
