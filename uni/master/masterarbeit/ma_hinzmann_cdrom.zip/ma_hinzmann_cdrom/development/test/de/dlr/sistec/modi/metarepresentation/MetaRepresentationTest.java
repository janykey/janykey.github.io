/*
 * MetaRepresentationTest.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: MetaRepresentationTest.java 204 2007-03-28 08:05:50Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.metarepresentation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.Model.Type;

public class MetaRepresentationTest extends TestCase {

    private IMetaRepresentation metaRepresentation = null;
    
    /**
     * @param name
     */
    public MetaRepresentationTest(String name) {
        super(name);
    }
    
    public void setUp() {
        metaRepresentation = MetaRepresentation.getInstance(); 
    }

    public void testMetaRepresentation() {
        assertNotNull(metaRepresentation);
        assertNotNull(metaRepresentation.getAmModel());
        assertNotNull(metaRepresentation.getDmModel());

        String defaultMetaRepresentation = metaRepresentation.toString();
        assertTrue(defaultMetaRepresentation != null);
    }

    public void testSetModel() {
        IModel aModel = new Model();
        aModel.setType(Type.AM);
        metaRepresentation.setAmModel(aModel);
        assertEquals(aModel, metaRepresentation.getAmModel());
        
        metaRepresentation.setDmModel(aModel);
        assertEquals(aModel, metaRepresentation.getDmModel());
        
    }
}
