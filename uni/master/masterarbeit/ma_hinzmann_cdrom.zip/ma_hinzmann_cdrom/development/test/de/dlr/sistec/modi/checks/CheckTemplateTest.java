/*
 * CheckTemplateTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 26, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.CheckTemplate;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.report.impl.Report;

/**
 * @author Jan Hinzmann
 *
 */
public class CheckTemplateTest extends TestCase {

    private CheckTemplate check;
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        check = new CheckTemplate();
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     *  .CheckTemplate#Check()}.
     */
    public void testCheck() {
        List<IDifference> differences = new Report().getDifferences();
        assertNotNull(check.check(differences));
        assertTrue(check.check(differences) instanceof List);
        assertTrue(check.check(differences).isEmpty());
    }

}
