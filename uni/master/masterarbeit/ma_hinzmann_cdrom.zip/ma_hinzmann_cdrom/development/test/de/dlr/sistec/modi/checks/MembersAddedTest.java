/*
 * MembersAddedTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 26, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.ModelItemsModified;
import de.dlr.sistec.modi.checks.impl.MembersAdded;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 * 
 */
public class MembersAddedTest extends TestCase {

    private IMetaRepresentation metarepresenation;

    private IModel architectsModel;

    private IModel developersModel;

    private IModelItem dmModelItem;

    private IModelItem amModelItem;

    private IComparator comparator;

    private ICheck interfacesModified; // precondition for membersAdded

    private ICheck membersAdded;

    /**
     * @param name
     */
    public MembersAddedTest(String name) {
        super(name);
    }

    public void setUp() {
        metarepresenation = MetaRepresentation.getInstance();
        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);

        developersModel = new Model();
        developersModel.setType(Model.Type.DM);

        dmModelItem = new ModelItem();
        dmModelItem.setType("interface");
        dmModelItem.setName("AnInterface");

        amModelItem = new ModelItem();
        amModelItem.setType("interface");
        amModelItem.setName("AnInterface");

        developersModel.addModelItem(dmModelItem);
        architectsModel.addModelItem(amModelItem);

        metarepresenation.setAmModel(architectsModel);
        metarepresenation.setDmModel(developersModel);

        // precondition for membersAdded
        interfacesModified = new ModelItemsModified();
        membersAdded = new MembersAdded();

        comparator = new Comparator();
        comparator.add(interfacesModified);
        comparator.add(membersAdded);

    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     * .MembersAdded#check()}.
     */
    public void testMembersAdded() {

        IReport report = comparator.evaluate();

        assertNotNull("The check must not return null.", report);

        assertTrue("The models are equal, so the list of differences must be "
                + "empty", report.getDifferences().isEmpty());

        dmModelItem.addMember(new Operation());
        report = comparator.evaluate();

        List<IDifference> differences = report.getDifferences();
        assertFalse(differences.isEmpty());
        assertTrue("After adding an operation to the DM item, there must be 2 "
                + "differences - found " + differences.size(),
                differences.size() == 2);

        assertEquals("After adding an operation to the DM the resulting "
                + "difference must have the state MODIFIED",
                IDifference.Status.MODIFIED, differences.get(0).getStatus());

        assertEquals("After adding an operation to the DM the resulting "
                + "difference must have the state ADDED",
                IDifference.Status.ADDED, differences.get(1).getStatus());
    }

}
