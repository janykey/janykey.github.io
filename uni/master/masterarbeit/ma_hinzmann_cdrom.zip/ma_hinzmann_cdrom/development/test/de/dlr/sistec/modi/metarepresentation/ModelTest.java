/*
 * ModelTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;
import de.dlr.sistec.modi.metarepresentation.impl.Variable;
import de.dlr.sistec.modi.metarepresentation.impl.Model.Type;

public class ModelTest extends TestCase {

    private IModel model;
    private IModel other;

    public ModelTest() {
        model = new Model();
        other = new Model();
    }

    public void setUp() {
        IModelItem item = new ModelItem();
        item.setName("anItem");
        item.setNamespace("de.dlr.modi");
        item.setType("interface");
        
        Operation operation = new Operation();
        operation.setName("anOperation");
        operation.setNamespace(item.getIdentifier());
        
        Parameter parameter = new Parameter();
        parameter.setName("aParameter");
        parameter.setNamespace(operation.getIdentifier());
        
        operation.addParameter(parameter);
        
        Variable variable = new Variable();
        variable.setName("aVariable");
        variable.setNamespace(item.getIdentifier());

        item.addMember(operation);
        item.addMember(variable);
        
        //these two models are equal
        model.addModelItem(item);
        other.addModelItem(item);
    }
    
    /**
     * Test method for
     * {@link de.dlr.sistec.modi.metarepresentation.impl.Model#Model()}.
     */
    public void testModel() {
        assertNotNull(model.getAuthor());
        assertNotNull(model.getItems());
        assertNotNull(model.getRevision());
        assertNotNull(model.getType());
        assertEquals(Type.UNDEFINED, model.getType());
    }

    public void testToString(){
        assertNotNull(new Model().toString());
    }
    
    public void testSetItems(){
        IModel newModel = new Model();
        List<IModelItem> newItems = new ArrayList<IModelItem>();
        newModel.setItems(newItems);
        assertSame(newItems, newModel.getItems());
    }
    
    public void testAddModelItem(){
        IModel newModel = new Model();
        assertTrue(newModel.getItems().isEmpty());
        ModelItem newItem = new ModelItem();
        newModel.addModelItem(newItem);
        assertTrue(newModel.getItems().contains(newItem));
    }
    
    /**
     * The equals method implements an equivalence relation.
     * <ul>
     * <li><b>It is reflexive:</b> for any reference value x, x.equals(x)
     * should return true. </li>
     * <li><b>It is symmetric:</b> for any reference values x and y,
     * x.equals(y) should return true if and only if y.equals(x) returns true.
     * </li>
     * <li><b>It is transitive:</b> for any reference values x, y, and z, if
     * x.equals(y) returns true and y.equals(z) returns true, then x.equals(z)
     * should return true.</li>
     * <li><b>It is consistent:</b> for any reference values x and y, multiple
     * invocations of x.equals(y) consistently return true or consistently
     * return false, provided no information used in equals comparisons on the
     * object is modified.</li>
     * <li>For any non-null reference value x, x.equals(null) should return
     * false.
     * </ul>
     */
    public void testEquals() {

        assertFalse(model.equals(null));
        assertTrue(model.equals(model));
        assertTrue(model.equals(other));

        //author
        model.setAuthor("Jan Hinzmann");
        assertFalse(model.equals(other));
        other.setAuthor("Jan Hinzmann");
        assertTrue(model.equals(other));

        //type
        model.setType(Type.AM);
        assertFalse(model.equals(other));
        other.setType(Type.AM);
        assertTrue(model.equals(other));

        //revision
        model.setRevision("r123");
        assertFalse(model.equals(other));
        other.setRevision("r123");
        assertTrue(model.equals(other));

        //items
        assertTrue(model.equals(other));
        ModelItem newItem = new ModelItem();
        newItem.setName("anIdentifier");
        newItem.setType("interface");
        
        Operation operation = new Operation();
        operation.setName("voidFoo");
        operation.setNamespace(newItem.getIdentifier());
        newItem.addMember(operation);
        
        model.addModelItem(newItem);
        assertFalse(model.equals(other));
        
        other.addModelItem(newItem);
        assertTrue(model.equals(other));
    }

    
    public void testEqualsAfterInterfaceAdded() {
        assertEquals(model, other);
        
        ModelItem amItem = new ModelItem();
        amItem.setName("anotherInterface");
        amItem.setType("interface");
        
        Operation amOperation = new Operation();
        amOperation.setName("anotherMethod");
        amOperation.setNamespace(amItem.getIdentifier());
        
        Parameter amParameter = new Parameter();
        amParameter.setName("aParameter");
        amParameter.setNamespace(amOperation.getIdentifier());
        
        amOperation.addParameter(amParameter);
        amItem.addMember(amOperation);
        model.addModelItem(amItem);
        
        assertFalse(model.equals(other));
        
        ModelItem dmItem = new ModelItem();
        dmItem.setName("anotherInterface");
        dmItem.setType("interface");
        
        Operation dmOperation = new Operation();
        dmOperation.setName("anotherMethod");
        dmOperation.setNamespace(dmItem.getIdentifier());
        
        Parameter dmParameter = new Parameter();
        dmParameter.setName("aParameter");
        dmParameter.setNamespace(dmOperation.getIdentifier());
        
        dmOperation.addParameter(dmParameter);
        dmItem.addMember(dmOperation);
        other.addModelItem(dmItem);
        
        assertTrue(model.equals(other));
        
        //now the developer adds a parameter to the method:
        Parameter newParameter = new Parameter();
        newParameter.setName("newParameter");
        dmOperation.addParameter(newParameter);
        
        assertFalse(model.equals(other));
    }
    
    
    /**
     * <b>The equals method is reflexive:</b> for any reference value x, 
     * x.equals(x) should return true.
     */
    public void testEqualsReflexive() {
        IModel x = new Model();
        assertTrue(x.equals(x));
    }

    /**
     * <b>The equals method is symmetric:</b> for any reference values x and y, 
     * x.equals(y) should return true if and only if y.equals(x) returns true.
     */
    public void testEqualsSymmetric() {
        IModel x = new Model();
        IModel y = new Model();
        assertTrue(x.equals(y) && y.equals(x));
    }
    
    /**
     * <b>The equals method is transitive:</b> for any reference values x, y, 
     * and z, if x.equals(y) returns true and y.equals(z) returns true, then 
     * x.equals(z) should return true.
     */
    public void testEqualsTransivity() {
        IModel x = new Model();
        IModel y = new Model();
        IModel z = new Model();
        //(x=y)&(y=z)=>(x=z) , x=>y is not(x)||y
        assertTrue((!(x.equals(y) && y.equals(z)) || x.equals(z)));
        //more readable
        assertTrue(x.equals(y));
        assertTrue(y.equals(z));
        assertTrue(x.equals(z));
    }

}
