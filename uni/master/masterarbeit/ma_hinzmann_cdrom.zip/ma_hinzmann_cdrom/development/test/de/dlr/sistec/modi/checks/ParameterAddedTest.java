/*
 * ParameterAddedTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import junit.framework.TestCase;

/**
 * @author Jan Hinzmann
 *
 */
public class ParameterAddedTest extends TestCase {

    /**
     * @param name
     */
    public ParameterAddedTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
    }

    
    public void testCheck(){
        fail("Not yet implemented");
    }
}
