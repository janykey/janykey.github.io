/*
 * MembersRemovedTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.ModelItemsModified;
import de.dlr.sistec.modi.checks.impl.MembersRemoved;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 *
 */
public class MembersRemovedTest extends TestCase {


    private IMetaRepresentation metarepresenation;

    private IModel architectsModel;

    private IModel developersModel;

    private IModelItem dmModelItem;

    private IModelItem amModelItem;

    private IComparator comparator;

    private ICheck interfacesModified; // precondition for membersRemoved

    private ICheck membersRemoved;

    /**
     * @param name
     */
    public MembersRemovedTest(String name) {
        super(name);
    }

    /**
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        amModelItem = new ModelItem();
        amModelItem.setType("interface");
        amModelItem.setName("AnInterface");

        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);
        architectsModel.addModelItem(amModelItem);

        dmModelItem = new ModelItem();
        dmModelItem.setType("interface");
        dmModelItem.setName("AnInterface");

        developersModel = new Model();
        developersModel.setType(Model.Type.DM);
        developersModel.addModelItem(dmModelItem);
        
        metarepresenation = MetaRepresentation.getInstance();
        metarepresenation.setAmModel(architectsModel);
        metarepresenation.setDmModel(developersModel);

        // precondition for membersRemoved
        interfacesModified = new ModelItemsModified();
        membersRemoved = new MembersRemoved();

        comparator = new Comparator();
        comparator.add(interfacesModified);
        comparator.add(membersRemoved);

    }

    public void testCheckRemoved() {
        IReport report = comparator.evaluate();
        assertNotNull(report);

        List<IDifference> differences = report.getDifferences();
        assertNotNull(differences);
        
        assertTrue(differences.isEmpty());
        
        //now we modify the model: adding a member to the AM is equal to remove
        //the member from the DM
        amModelItem.addMember(new Operation());

        //reevaluate
        report = comparator.evaluate();
        differences = report.getDifferences();
        
        assertFalse(differences.isEmpty());
        assertTrue("There must be 2 differences. Found: " + differences.size(),
                differences.size() == 2);
        
        assertEquals("There must be a Difference in the state MODIFIED", 
                IDifference.Status.MODIFIED,
                report.getDifferences().get(0).getStatus());
        
        assertEquals("There must be a Difference in the state REMOVED",
                IDifference.Status.REMOVED,
                report.getDifferences().get(1).getStatus());
        
    }
    
}
