/*
 * ComparatorTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 26, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.evaluation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.ICheck;
import de.dlr.sistec.modi.checks.impl.InterfacesAdded;
import de.dlr.sistec.modi.checks.impl.ModelItemsModified;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 * 
 */
public class ComparatorTest extends TestCase {

    IComparator comparator;

    /**
     * @param name
     */
    public ComparatorTest(String name) {
        super(name);
    }

    /*
     * (non-Javadoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        comparator = new Comparator();
    }

    public void testComparator() {
        assertNotNull(comparator.getChecks());
        assertTrue(comparator.getChecks().isEmpty());
    }


    /**
     * Test method for {@link de.dlr.sistec.modi.evaluation.impl.Comparator#add(de.dlr.sistec.modi.checks.ICheck)}.
     */
    public void testAddCheck() {
        assertNotNull("The List of ICheck must not be null", comparator
                .getChecks());

        assertTrue("The List of ICheck must be empty", comparator.getChecks()
                .isEmpty());

        comparator.add(new ModelItemsModified());

        assertTrue("After adding 1 Check the count of Checks must be 1",
                comparator.getChecks().size() == 1);
    }



    /**
     * Test method for {@link de.dlr.sistec.modi.evaluation.impl.Comparator#evaluate()}.
     */
    public void testEvaluate() {
        assertNotNull(comparator.evaluate());
    }

}
