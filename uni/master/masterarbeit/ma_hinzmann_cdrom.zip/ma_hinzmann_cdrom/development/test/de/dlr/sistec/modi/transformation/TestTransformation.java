/*
 * TestImports.java
 *
 * <Beschreibung>
 *
 * Created: Apr 16, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.MoDi;
import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;

/**
 * @author Jan Hinzmann
 *
 */
public class TestTransformation extends TestCase {

    MoDi modi;
    MoDi.ImportHandler handler;;
    /**
     * @param name
     */
    public TestTransformation(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        modi = new MoDi();
        handler = MoDi.ImportHandler.FILESYSTEM;
        
        String amRoot = "testdata/extendsList";
        try {
            modi.findArchitectsModelFiles(handler, amRoot, "java");
            modi.transformArchitectsModel(MoDi.Language.JAVA);
        } catch (MoDiException e) {
            fail(e.getMessage());
        }
        
    }

    public void testImports() {
        IMetaRepresentation rep = MetaRepresentation.getInstance();
        
        List<IModelItem> elements = rep.getAmModel().getItems();

        IModelItem importsALot = null;
        for (IModelItem item : elements) {
            if (item.getIdentifier().equals("ImportsALot")){
                importsALot = item;
            }
        }
        assertNotNull("ImportsALot could not be found.", importsALot);
        
        assertTrue("There should be 2 import statements", 
                (importsALot.getImports().size() == 2));
        
        assertEquals("java.util.Iterator", importsALot.getImports().get(0));
        assertEquals("java.util.List", importsALot.getImports().get(1));
    }
    
    public void testExtends() {
       
        IMetaRepresentation rep = MetaRepresentation.getInstance();
        List<IModelItem> elements = rep.getAmModel().getItems();
        
        IModelItem extendsALot = null;
        for (IModelItem item : elements) {
            if (item.getIdentifier().equals("IExtendALot")){
                extendsALot = item;
            }
        }
        assertNotNull("IExtendALot could not be found.", extendsALot);
        
        List<IModelItem> extendsList = extendsALot.getExtendees();
        int expected = 4;
        int actual = extendsList.size();
        assertTrue("There should be 4 super classes in the extends list, "
                + "found: " + actual, expected == actual);
        
        //Foo, Bar, List, Blubb
        String[] expectedExtendees = {"Foo", "Bar", "List", "Blubb"};
        for (int i = 0; i < 4; i++) {
            assertEquals("The extendee " + expectedExtendees[i] +" did not occur",
                    expectedExtendees[i], extendsList.get(i).getIdentifier());
        }
        
    }
    
    public void testImplements() {
        IMetaRepresentation rep = MetaRepresentation.getInstance();
        List<IModelItem> elements = rep.getAmModel().getItems();
        
        IModelItem implementsALot = null;
        for (IModelItem item : elements) {
            if (item.getIdentifier().equals("ImplementsALot")){
                implementsALot = item;
            }
        }
        assertNotNull("ImplementsALot could not be found.", implementsALot);
       

        List<IModelItem> implementsList = implementsALot.getExtendees();
        int expected = 4;
        int actual = implementsList.size();
        assertTrue("There should be 4 super classes in the extends list, "
                + "found: " + actual, expected == actual);
        
        //Foo, Bar, List, Blubb
        String[] expectedImplemented = {"Foo", "Bar", "List", "Blubb"};
        for (int i = 0; i < 4; i++) {
            assertEquals("The implemented " + expectedImplemented[i] +" did not occur",
                    expectedImplemented[i], implementsList.get(i).getIdentifier());
        }
        
    }
}
