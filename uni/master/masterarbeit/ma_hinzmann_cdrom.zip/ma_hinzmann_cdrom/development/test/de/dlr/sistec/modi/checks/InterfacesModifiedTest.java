/*
 * InterfacesModified.java
 *
 * <Beschreibung>
 *
 * Created: Mar 26, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.ModelItemsModified;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 * 
 */
public class InterfacesModifiedTest extends TestCase {

    private IMetaRepresentation metarepresenation;

    private IModel architectsModel;

    private IModel developersModel;

    private IModelItem dmModelItem;

    private IModelItem amModelItem;

    private IComparator comparator;

    private ICheck interfacesModified;

    public void setUp() {
        metarepresenation = MetaRepresentation.getInstance();
        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);

        developersModel = new Model();
        developersModel.setType(Model.Type.DM);

        dmModelItem = new ModelItem();
        dmModelItem.setType("interface");
        dmModelItem.setName("AddedInterface");

        amModelItem = new ModelItem();
        amModelItem.setType("interface");
        amModelItem.setName("AddedInterface");

        architectsModel.addModelItem(amModelItem);
        developersModel.addModelItem(dmModelItem);
        metarepresenation.setAmModel(architectsModel);
        metarepresenation.setDmModel(developersModel);

        comparator = new Comparator();
        interfacesModified = new ModelItemsModified();

        comparator.add(interfacesModified);
    }

    /**
     * @param name
     */
    public InterfacesModifiedTest(String name) {
        super(name);
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     * .ModelItemsModified#check()}. An Interfaces has been modified if
     * <ul>
     * <li>a Member has been added</li>
     * <li>a Member has been removed</li>
     * <li>a Member has been modified</li>
     * </ul>
     */
    public void testInterfacesModified() {
        IReport report = comparator.evaluate();
        List<IDifference> differencesFound = report.getDifferences();

        assertNotNull("The list of differences must not be null",
                differencesFound);

        assertTrue("The check method must return at least an empty list of "
                + "differences", differencesFound.isEmpty());

        // now we modifiy an interface
        Operation operation = new Operation();
        dmModelItem.addMember(operation);

        report = comparator.evaluate();
        differencesFound = report.getDifferences();

        assertTrue(
                "A Member has been added. This should result in a difference",
                differencesFound.size() == 1);
        assertEquals("After adding an operation in the DM there must be a "
                + "difference with the status MODIFIED.",
                IDifference.Status.MODIFIED, differencesFound.get(0)
                        .getStatus());
    }

    public void testDifferencesContainBothInterfacesModified() {
        
        IReport report = comparator.evaluate();
        List<IDifference> differences = report.getDifferences();

        assertNotNull(report);
        assertNotNull(differences);
        assertTrue(differences.isEmpty());
       
        dmModelItem.addMember(new Operation());
        
        report = comparator.evaluate();
        differences = report.getDifferences();
        int diffs = differences.size();
        assertTrue("There must be one difference, found: " + diffs, diffs == 1);
        
        assertNotNull(differences.get(0).getAMElement());
        assertNotNull(differences.get(0).getDMElement());
        
        assertEquals(amModelItem, differences.get(0).getAMElement());
        assertEquals(dmModelItem, differences.get(0).getDMElement());
    }

}
