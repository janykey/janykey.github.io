/*
 * TestSuiteMoDi.java
 *
 * <Beschreibung>
 *
 * Created: Mar 24, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author Jan Hinzmann
 *
 */
public class TestSuiteMoDi extends TestCase {

    public static Test suite(){
        TestSuite suite = new TestSuite("MoDi TestSuite");

        // modi
        suite.addTestSuite(ConfigTest.class);
        
        return suite;
    }

}
