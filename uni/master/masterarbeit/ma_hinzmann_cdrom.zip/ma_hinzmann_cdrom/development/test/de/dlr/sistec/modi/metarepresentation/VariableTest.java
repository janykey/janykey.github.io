/*
 * VarableTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Variable;

/**
 * @author Jan Hinzmann
 *
 */
public class VariableTest extends TestCase {

    private IVariable variable;
    private static final String NAMESPACE = "MyClass";
    
    /**
     * @param name
     */
    public VariableTest(String name) {
        super(name);
    }

    /**
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        variable = new Variable();
        variable.setName("myVar");
        variable.setNamespace(NAMESPACE);
    }



    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Variable#Variable()}.
     */
    public void testVariable() {
        assertNotNull(variable.getValue());
        char unexpected = '.';
        char actual = variable.getIdentifier().charAt(0);
        assertTrue("The identifier must not begin with a period(., "
                + actual + ").", unexpected != actual);
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl        
     *          .Variable#setValue(java.lang.String)}.
     */
    public void testSetValue() {
        String newValue = "new value";
        variable.setValue(newValue);
        assertEquals(newValue, variable.getValue());
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Variable#toString()}.
     */
    public void testToString() {
        assertNotNull(variable.toString());
        assertTrue(variable.toString() instanceof String);
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.metarepresentation.impl
     *          .Variable#equals(java.lang.Object)}.
     */
    public void testEqualsObject() {
        assertFalse(variable.equals(null));
        assertTrue(variable.equals(variable));
    }
}
