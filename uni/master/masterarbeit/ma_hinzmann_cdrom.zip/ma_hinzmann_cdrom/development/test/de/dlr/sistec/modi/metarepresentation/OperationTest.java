/*
 * OperationTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 21, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;

/**
 * @author Jan Hinzmann
 *
 */
public class OperationTest extends TestCase {

    private Operation operation;
    
    /**
     * @param name
     */
    public OperationTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        operation = new Operation();
    }

    public void testOperation(){
        assertNotNull(operation.getIdentifier());
        assertNotNull(operation.getModifiers());
        assertNotNull(operation.getParameters());
        assertNotNull(operation.getType());        
    }
    
    public void testEquals(){
        assertFalse(operation.equals(null));
        assertTrue(operation.equals(operation));
    }
    
    public void testToString(){
        String operationString = operation.toString();
        operation.addParameter(new Parameter());
        assertNotNull(operationString);

    }
}
