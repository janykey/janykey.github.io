/*
 * TestFileFinder.java
 *
 * <Beschreibung>
 *
 * Created: Mar 16, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $$Id$$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import java.io.File;
import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.Config;
import de.dlr.sistec.modi.MoDi;
import de.dlr.sistec.modi.exception.MoDiException;

/**
 * @author Jan Hinzmann
 * 
 */
public class TestFileFinder extends TestCase {

    private IFileFinder finder = null;

    private String fileExtension = null;

    private File rootDir = null;

    public void setUp() {
        finder = FileFinderFactory.create(MoDi.ImportHandler.FILESYSTEM);
        rootDir = new File("testdata/twoJavaFiles");
        fileExtension = "java";

        assertNotNull("finder must not be null", finder);
    }

    public void testFindFilesNullNull() {

        try {
            finder.findFiles(null, null);
            fail("ModiException expected!");
        } catch (MoDiException e) {
            assertTrue(e.getMessage() != null);
        }
    }

    public void testFindFilesRootDirNull() {

        try {
            finder.findFiles(rootDir, null);
            fail("ModiException expected!");
        } catch (MoDiException e) {
            assertTrue(e.getMessage() != null);
        }
    }

    public void testFindFilesNullFileExtension() {
        try {
            finder.findFiles(null, fileExtension);
            fail("ModiException expected!");
        } catch (MoDiException e) {
            assertTrue(e.getMessage() != null);
        }

    }

    public void testFindFiles() {
        try {
            List<File> filesFound = finder.findFiles(rootDir, fileExtension);
            assertFalse(filesFound.isEmpty());
            assertEquals(2, filesFound.size());

        } catch (MoDiException e) {
            fail("cought MoDiexception: " + e.getMessage());
        }
    }
}
