/*
 * ModelItemTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;

public class ModelItemTest extends TestCase {

    ModelItem modelItem;

    public void setUp() {
        modelItem = new ModelItem();
    }

    /**
     * Test method for
     * {@link de.dlr.sistec.modi.metarepresentation.impl.ModelItem#ModelItem()}.
     */
    public void testModelItem() {
        assertNotNull(modelItem.getExtendees());
        assertNotNull(modelItem.getIdentifier());
        assertNotNull(modelItem.getMembers());
        assertNotNull(modelItem.getModifiers());
        assertNotNull(modelItem.getNamespace());
        assertNotNull(modelItem.getType());
    }

    /**
     * Test method for
     * {@link de.dlr.sistec.modi.metarepresentation.impl.ModelItem#equals(java.
     * lang.Object)}.
     */
    public void testEquals() {
        ModelItem other = new ModelItem();

        assertFalse(modelItem.equals(null));
        assertTrue(modelItem.equals(modelItem));
        assertTrue(modelItem.equals(other));

        modelItem.setName("IModelItem");
        assertFalse(modelItem.equals(other));
        other.setName("IModelItem");
        assertTrue(modelItem.equals(other));

        modelItem.setNamespace("de.dlr.sistec.modi");
        assertFalse(modelItem.equals(other));
        other.setNamespace("de.dlr.sistec.modi");
        assertTrue(modelItem.equals(other));

        modelItem.setType("interface");
        assertFalse(modelItem.equals(other));
        other.setType("interface");
        assertTrue(modelItem.equals(other));

        modelItem.addExtendee(new ModelItem());
        assertFalse(modelItem.equals(other));
        other.addExtendee(new ModelItem());
        assertTrue(modelItem.equals(other));

        //operation
        Operation modelItemOperation = new Operation();
        modelItem.addMember(modelItemOperation);
        assertFalse(modelItem.equals(other));

        Operation othersOperation = new Operation();
        other.addMember(othersOperation);
        assertTrue(modelItem.equals(other));
        
        Parameter modelItemParameter = new Parameter();
        modelItemOperation.addParameter(modelItemParameter);
        assertFalse(modelItem.equals(other));
        
        Parameter othersParameter = new Parameter();
        othersOperation.addParameter(othersParameter);
        assertTrue(modelItem.equals(other));
        
        
        // other.addMember(new Variable());
        // assertFalse(modelItem.equals(other));
    }

    
    /**
     * <b>The equals method is reflexive:</b> for any reference value x, 
     * x.equals(x) should return true.
     */
    public void testEqualsReflexive() {
        ModelItem x = new ModelItem();
        assertTrue(x.equals(x));
    }

    /**
     * <b>The equals method is symmetric:</b> for any reference values x and y, 
     * x.equals(y) should return true if and only if y.equals(x) returns true.
     */
    public void testEqualsSymmetric() {
        ModelItem x = new ModelItem();
        ModelItem y = new ModelItem();
        assertTrue(x.equals(y) && y.equals(x));
    }
    
    /**
     * <b>The equals method is transitive:</b> for any reference values x, y, 
     * and z, if x.equals(y) returns true and y.equals(z) returns true, then 
     * x.equals(z) should return true.
     */
    public void testEqualsTransivity() {
        ModelItem x = new ModelItem();
        ModelItem y = new ModelItem();
        ModelItem z = new ModelItem();
        assertTrue(x.equals(y) && y.equals(z) && x.equals(z));
    }
    

}
