/*
 * DifferenceTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.evaluation;

import de.dlr.sistec.modi.evaluation.impl.Difference;
import junit.framework.TestCase;

/**
 * @author Jan Hinzmann
 *
 */
public class DifferenceTest extends TestCase {

    private IDifference difference;
    
    /**
     * @param name
     */
    public DifferenceTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        difference = new Difference();
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.evaluation.impl.Difference#Difference()}.
     */
    public void testDifference() {
        assertNotNull("The AMElement must not be null",
                difference.getAMElement());
        assertNotNull("The description must not be null", 
                difference.getDescription());
        assertNotNull("The DMElement must not be null",
                difference.getDMElement());
        assertNotNull("The layer must not be null", difference.getLayer());
        assertNotNull("The name must not be null", difference.getName());
        assertNotNull("The parentElement must not be null",
                difference.getParentElement());
        assertNotNull("The status must not be null",
                difference.getStatus());
    }



}
