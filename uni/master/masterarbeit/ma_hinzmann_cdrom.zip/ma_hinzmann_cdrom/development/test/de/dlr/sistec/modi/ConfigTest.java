/*
 * ConfigTest.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi;

import junit.framework.TestCase;
import de.dlr.sistec.modi.exception.MoDiException;

/*
 * ConfigTest.java
 * 
 * <Beschreibung>
 * 
 * Created: Mar 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de> Changed:
 * 
 * $Id$
 * 
 * Copyright (C) 2007 DLR SC, Germany
 * 
 * All rights reserved
 * 
 * http://www.dlr.de/sc
 */

/**
 * @author Jan Hinzmann
 * 
 */
public class ConfigTest extends TestCase {

    
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        String userdir = System.getProperty("user.dir");
        String value = userdir + "/testdata/testConfig/config.properties";
        System.setProperty("MODICONFIG", value);
    }

    /**
     * Test method for
     * {@link de.dlr.sistec.modi.Config#getStringProperty(java.lang.String)}.
     */
    public void testGetNullProperty() {
        try {
            Config.getStringProperty(null);
            fail("retrieving a property for \"null\" should result in "
                    + "an exception");
        } catch (MoDiException e) {
            assertNotNull(e.getMessage());
        }

    }
    
    /**
     * Test method for getStringProperty
     * MoDi.test.JustAString = justastring
     * {@link de.dlr.sistec.modi.Config#getStringProperty(java.lang.String)}.
     */
    public void testGetStringProperty() {
        String expected = "justastring";
        try {
            assertEquals(expected, Config
                    .getStringProperty("MoDi.test.JustAString"));
        } catch (MoDiException e) {
            fail("The StringProperty \"MoDi.test.JustAString\" " 
                    + "could not be retrieved");
        }
    }

}
