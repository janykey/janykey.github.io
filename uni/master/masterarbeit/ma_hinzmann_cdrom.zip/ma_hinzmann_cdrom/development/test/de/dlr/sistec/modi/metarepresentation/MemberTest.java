/*
 * MemberTest.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.metarepresentation;

import junit.framework.TestCase;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;
import de.dlr.sistec.modi.metarepresentation.impl.Variable;

/**
 * @author Jan Hinzmann
 * 
 */
public class MemberTest extends TestCase {

    // Members are operations or variables.

    private static final String NAMESPACE = "MyClass";
    /**
     * An Operation is a Member which has a list of parameters in addition.
     */
    private Operation operation = null;

    /**
     * A variavble is a Member shich has a value in addition.
     */
    private Variable variable = null;

    public MemberTest(){
        this.setName(this.getClass().getName());
    }
    
    public void setUp() {
        operation = new Operation();
        operation.setName("execute");
        operation.setNamespace(NAMESPACE);
        
        variable = new Variable();
        variable.setName("aMember");
        variable.setNamespace(NAMESPACE);
    }

    public void testGetOperationIdentifier() {
        char unexpected = '.';
        char actual = operation.getIdentifier().charAt(0);
        
        assertTrue("The identifier must not start with a period ("+actual+").", 
                unexpected != actual);
        
        operation.setName("foo");
        
        actual = operation.getIdentifier().charAt(0);
        assertTrue("The identifier must not start with a period ("+actual+").", 
                unexpected != actual);
        
        operation.setNamespace("MyClass");
        
        actual = operation.getIdentifier().charAt(0);
        assertTrue("The identifier must not start with a period ("+actual+").", 
                unexpected != actual);
            
    }
    
    public void testGetVariableIdentifier() {
        char unexpected = '.';
        char actual = variable.getIdentifier().charAt(0);
        
        assertTrue("The identifier must not start with a period ("+actual+").", 
                unexpected != actual);
        
        variable.setName("foo");
        
        actual = variable.getIdentifier().charAt(0);
        assertTrue("The identifier must not start with a period ("+actual+").", 
                unexpected != actual);
        
        variable.setNamespace("MyClass");
        
        actual = variable.getIdentifier().charAt(0);
        assertTrue("The identifier must not start with a period ("+actual+").", 
                unexpected != actual);
            
    }
    
    public void testOperation() {
        assertNotNull("The identifier of a new operation must not be null.",
                operation.getIdentifier());
        
        assertNotNull("The modifiers of a new operation must not be null.",
                operation.getModifiers());
        
        assertTrue("The list of modifiers must be empty.", 
                operation.getModifiers().isEmpty());
        
        assertNotNull("The type of an operation must not be null.", 
                operation.getType());
        
        assertNotNull("The list of parameters must not be null.", 
                operation.getParameters());
        
        assertTrue("The list of parameters must be empty.", 
                operation.getParameters().isEmpty());
    }

    
    public void testOperationEquals() {
        assertFalse(operation.equals(null));
        assertTrue("An opration must be equal to it self.",
                operation.equals(operation));

        Operation otherOperation = new Operation();
        otherOperation.setNamespace(NAMESPACE);

        String identifier = "getValue";
        operation.setName(identifier);
        assertFalse(operation.equals(otherOperation));

        otherOperation.setName(identifier);
        assertTrue(operation.equals(otherOperation));
        
        Parameter parameter = new Parameter();
        operation.addParameter(parameter);
        assertFalse(operation.equals(otherOperation));

        otherOperation.addParameter(parameter);
        assertTrue(operation.equals(otherOperation));
        
        parameter.setName("i");
    }

    /**
     * <b>The equals method is reflexive:</b> for any reference value x, 
     * x.equals(x) should return true.
     */
    public void testOperationEqualsReflexive() {
        IOperation x = new Operation();
        assertTrue(x.equals(x));
    }

    /**
     * <b>The equals method is symmetric:</b> for any reference values x and y, 
     * x.equals(y) should return true if and only if y.equals(x) returns true.
     */
    public void testOperationEqualsSymmetric() {
        IOperation x = new Operation();
        IOperation y = new Operation();
        assertTrue(x.equals(y) && y.equals(x));
    }
    
    /**
     * <b>The equals method is transitive:</b> for any reference values x, y, 
     * and z, if x.equals(y) returns true and y.equals(z) returns true, then 
     * x.equals(z) should return true.
     */
    public void testOperationEqualsTransivity() {
        IOperation x = new Operation();
        IOperation y = new Operation();
        IOperation z = new Operation();
        assertTrue(x.equals(y) && y.equals(z) && x.equals(z));
    }
    
    public void testVariable() {
        assertNotNull(variable.getIdentifier());
        assertNotNull(variable.getModifiers());
        assertNotNull(variable.getType());
        assertNotNull(variable.getValue());
    }
    

    public void testVariableEquals() {
        assertFalse(variable.equals(null));
        assertTrue(variable.equals(variable));
    }

    
    
}
