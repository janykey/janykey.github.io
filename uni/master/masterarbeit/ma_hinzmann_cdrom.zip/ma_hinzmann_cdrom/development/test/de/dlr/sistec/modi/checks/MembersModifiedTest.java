/*
 * MembersModifiedTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.MembersModified;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.IParameter;
import de.dlr.sistec.modi.metarepresentation.IVariable;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;
import de.dlr.sistec.modi.metarepresentation.impl.Variable;

/**
 * @author Jan Hinzmann
 * 
 */
public class MembersModifiedTest extends TestCase {

    private List<IDifference> differences;

    private ICheck membersModified;

    private IModelItem amModelItem;

    private IModelItem dmModelItem;

    private IMember amMember;

    private IMember dmMember;

    private IModelItem voidTypeAM;

    private IModelItem voidTypeDM;

    /**
     * @param name
     */
    public MembersModifiedTest(String name) {
        super(name);
    }

    /*
     * (non-Javadoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();

        // an AM with an interface and a member in it
        // member: "public void aMember();"
        voidTypeAM = new ModelItem();
        voidTypeAM.setName("void");
        
        amModelItem = new ModelItem();
        amModelItem.setType("interface");
        amModelItem.setName("AnInterface");

        amMember = new Operation();
        amMember.addModifier("public");
        amMember.setType(voidTypeAM);
        amMember.setNamespace(amModelItem.getIdentifier());
        amMember.setName("aMember");

        amModelItem.addMember(amMember);

        // the DM with an interface and a member
        voidTypeDM = new ModelItem();
        voidTypeDM.setName("void");
        
        dmModelItem = new ModelItem();
        dmModelItem.setType("interface");
        dmModelItem.setName("AnInterface");

        dmMember = new Operation();
        dmMember.addModifier("public");
        dmMember.setType(voidTypeDM);
        dmMember.setNamespace(dmModelItem.getIdentifier());
        dmMember.setName("aMember");
        
        dmModelItem.addMember(dmMember);

        IDifference difference = new Difference();
        difference.setLayer(IDifference.Layer.MODELITEM);
        difference.setStatus(IDifference.Status.MODIFIED);
        difference.setAMElement((IModelElement) amModelItem);
        difference.setDMElement((IModelElement) dmModelItem);
        difference.setName("InterfacesModified");

        differences = new ArrayList<IDifference>();
        differences.add(difference);

        membersModified = new MembersModified();
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     * .MembersModified#check(java.util.List)}.
     */
    public void testCheckMemberModified() {
        List<IDifference> results = membersModified.check(differences);
        assertNotNull("The results must not be null", results);
        assertTrue(results.isEmpty());

        // now we modify the dmMember which must result in a MODIFIED difference
        dmMember.addModifier("static");

        results = membersModified.check(differences);
        assertTrue("Now there must be a difference", results.size() == 1);

        assertEquals("The difference must have the status MODIFIED",
                IDifference.Status.MODIFIED, results.get(0).getStatus());

        assertEquals("The difference must have the layer MEMBER",
                IDifference.Layer.MEMBER, results.get(0).getLayer());

        assertEquals("The AM element must be the one from the setup", amMember,
                results.get(0).getAMElement());

        assertEquals("The DM element must be the one from the setup", dmMember,
                results.get(0).getDMElement());

        assertEquals("The parentElement of the modified member must be the " 
                + "one from the setup",
                dmModelItem, results.get(0).getParentElement());
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     * .MembersModified#check(java.util.List)}.
     */
    public void testCheckOperationModified() {
    	//An Operation adds the Parameter to a member
    	amMember = new Operation();
    	dmMember = new Operation();
    	
    	amModelItem.addMember(amMember);
    	dmModelItem.addMember(dmMember);
    	List<IDifference> results = membersModified.check(differences);
        assertNotNull("The results must not be null", results);
        assertTrue(results.isEmpty());
        
        //now we modify a bit and run the check again.
        IParameter parameter = new Parameter();
        parameter.setName("newSize");
        ((IOperation)dmMember).addParameter(parameter);
        results = membersModified.check(differences);
        int size = results.size();
        assertTrue("Now there must be a difference <" + size + ">", size == 1);
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     * .MembersModified#check(java.util.List)}.
     */
    public void testCheckVariableModified() {
    	//A Variable adds the Value to the member
    	amMember = new Variable();
    	dmMember = new Variable();
    	
    	amModelItem.addMember(amMember);
    	dmModelItem.addMember(dmMember);
    	List<IDifference> results = membersModified.check(differences);
        assertNotNull("The results must not be null", results);
        assertTrue(results.isEmpty());
        
        //now we modify a bit and run the check again.
        ((IVariable)dmMember).setValue("foo");
        results = membersModified.check(differences);
        int size = results.size();
        assertTrue("Now there must be a difference <" + size + ">", size == 1);
    }
}
