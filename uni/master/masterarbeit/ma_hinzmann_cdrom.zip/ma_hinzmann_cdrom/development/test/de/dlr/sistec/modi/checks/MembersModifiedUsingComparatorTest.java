/*
 * MembersModifiedTest.java
 *
 * <Beschreibung>
 *
 * Created: Mar 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.ModelItemsModified;
import de.dlr.sistec.modi.checks.impl.MembersModified;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 *
 */
public class MembersModifiedUsingComparatorTest extends TestCase {

    private IMetaRepresentation metarepresenation;

    private IModel architectsModel;

    private IModel developersModel;

    private IModelItem amModelItem;

    private IModelItem dmModelItem;
    
    private IMember amMember;
    
    private IMember dmMember;
    
    private IModelItem voidTypeAM;
    
    private IModelItem voidTypeDM;

    private IComparator comparator;

    private ICheck interfacesModified; // precondition for membersModified

    private ICheck membersModified;
    
    /**
     * @param name
     */
    public MembersModifiedUsingComparatorTest(String name) {
        super(name);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        //an AM with an interface and a member in it
        voidTypeAM = new ModelItem();
        voidTypeAM.setName("void");
        
        amModelItem = new ModelItem();
        amModelItem.setType("interface");
        amModelItem.setName("AnInterface");
        amModelItem.addMember(amMember);
        
        amMember = new Operation();
        amMember.addModifier("public");
        amMember.addModifier("static");
        amMember.setType(voidTypeAM);
        amMember.setName("aMember");
        amMember.setNamespace(amModelItem.getIdentifier());

        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);
        architectsModel.addModelItem(amModelItem);

        
        //the DM with an interface and a member
        voidTypeDM = new ModelItem();
        voidTypeDM.setName("void");
        
        dmModelItem = new ModelItem();
        dmModelItem.setType("interface");
        dmModelItem.setName("AnInterface");
        dmModelItem.addMember(dmMember);

        dmMember = new Operation();
        dmMember.addModifier("public");
        dmMember.setType(voidTypeAM);
        dmMember.setName("aMember");
        dmMember.setNamespace(amModelItem.getIdentifier());

        developersModel = new Model();
        developersModel.setType(Model.Type.DM);
        developersModel.addModelItem(dmModelItem);
        
        
        //the metarepresentation with to 2 models
        metarepresenation = MetaRepresentation.getInstance();
        metarepresenation.setAmModel(architectsModel);
        metarepresenation.setDmModel(developersModel);

        // precondition for membersModified
        interfacesModified = new ModelItemsModified();
        membersModified = new MembersModified();

        comparator = new Comparator();
        comparator.add(interfacesModified);
        comparator.add(membersModified);
    }

    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     *          .MembersModified#check(java.util.List)}.
     */
    public void testCheckMemberModified() {
        IReport report = comparator.evaluate();
        List<IDifference> differences = report.getDifferences();
        assertTrue("There must not be differences at this point", 
                differences.isEmpty());
        
        //now we modify the member a bit
        //"public void aMember();" -> "public static void aMember();"
        dmMember.addModifier("static");
        
        report = comparator.evaluate();
        differences = report.getDifferences();
        
        assertTrue("Now we want differences!", differences.isEmpty());
        
    }
    
    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     *          .MembersModified#check(java.util.List)}.
     */
    public void testCheckOperationModified() {
//    	This is tested in MembersModifiedTest
    }

    
    /**
     * Test method for {@link de.dlr.sistec.modi.checks.impl
     *          .MembersModified#check(java.util.List)}.
     */
    public void testCheckVariableModified() {
    	//This is tested in MembersModifiedTest
    }
}
