/*
 * AddedPrivateMembersInClassesTest.java
 *
 * <Beschreibung>
 *
 * Created: May 30, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.checks.impl.AddedPrivateMembersInClasses;
import de.dlr.sistec.modi.checks.impl.AddedPublicMethodsInImplementingClasses;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import junit.framework.TestCase;

/**
 * @author Jan Hinzmann
 * 
 */
public class AddedPrivateMembersInClassesTest extends TestCase {

    private IMetaRepresentation metarepresenation;

    private IModel architectsModel;

    private IModel developersModel;

    private IModelItem amPizzaService;

    private IModelItem dmPizzaService;

    private IMember addedPrivateMethod;
    
    private ICheck addedPrivateMembersInClasses;

    /**
     * @param name
     */
    public AddedPrivateMembersInClassesTest(String name) {
        super(name);
    }

    /*
     * (non-Javadoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();

        setUpAM();
        setUpDM();

        addedPrivateMembersInClasses = new AddedPrivateMembersInClasses();

    }

    private void setUpAM() {
        /*
         * class PizzaService { public void setToppings(){} }
         */
        amPizzaService = new ModelItem();
        amPizzaService.setName("PizzaService");
        amPizzaService.setType("class");

        IMember amMethod = new Operation();
        amMethod.addModifier("public");
        amMethod.setName("setToppings");
        amPizzaService.addMember(amMethod);

        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);
        architectsModel.addModelItem(amPizzaService);

        metarepresenation = MetaRepresentation.getInstance();
        metarepresenation.setAmModel(architectsModel);
    }

    private void setUpDM() {
        /*
         * class PizzaService { public void setToppings(){} private void
         * imAdded(){} }
         */
        dmPizzaService = new ModelItem();
        dmPizzaService.setType("class");
        dmPizzaService.setName("PizzaService");

        IMember dmMethod = new Operation();
        dmMethod.addModifier("public");
        dmMethod.setName("setToppings");
        dmPizzaService.addMember(dmMethod);

        addedPrivateMethod = new Operation();
        addedPrivateMethod.addModifier("private");
        addedPrivateMethod.setName("imAdded");
        dmPizzaService.addMember(addedPrivateMethod);

        developersModel = new Model();
        developersModel.setType(Model.Type.DM);
        developersModel.addModelItem(dmPizzaService);

        metarepresenation = MetaRepresentation.getInstance();
        metarepresenation.setDmModel(developersModel);

    }

    public void testCheck() {
        List<IDifference> differences = 
            addedPrivateMembersInClasses.check(null);

        assertNotNull("The check method must not return null", differences);

        int size = differences.size();
        assertTrue("There must be one Difference <" + size + ">", size == 1);

        IDifference difference = differences.get(0);
        assertTrue("The DMElement of the difference must be the"
                + " added private method.", difference.getDMElement()
                .equals(addedPrivateMethod));
        
        assertTrue("The Parent element of the difference must be the one with the"
                + " added private method in it.", difference.getParentElement()
                .equals(dmPizzaService));
    }
}
