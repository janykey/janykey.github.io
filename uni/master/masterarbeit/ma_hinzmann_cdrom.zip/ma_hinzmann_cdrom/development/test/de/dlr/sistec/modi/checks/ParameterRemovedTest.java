/*
 * ParameterRemoved.java
 *
 * <Beschreibung>
 *
 * Created: Mar 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import junit.framework.TestCase;

/**
 * @author Jan Hinzmann
 * 
 */
public class ParameterRemovedTest extends TestCase {

    /**
     * @param name
     */
    public ParameterRemovedTest(String name) {
        super(name);
    }

    /*
     * (non-Javadoc)
     * 
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
    }

    /**
     * Test method for
     * {@link de.dlr.sistec.modi.checks.impl.ParameterRemoved
     * #check(java.util.List)}.
     */
    public void testCheck() {
        fail("Not yet implemented");
    }

}
