/*
 * InterfacesAddedTest.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $$Id$$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import junit.framework.TestCase;
import de.dlr.sistec.modi.checks.impl.InterfacesAdded;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 */
public class InterfacesAddedTest extends TestCase {

    private IMetaRepresentation metarepresenation;
    private IModel architectsModel;
    private IModel developersModel;
    private IModelItem dmModelItem;
    private IComparator comparator;
    private ICheck interfacesAddedCheck;


    public void setUp() {
        metarepresenation = MetaRepresentation.getInstance();
        architectsModel = new Model();
        architectsModel.setType(Model.Type.AM);
        
        developersModel = new Model();
        developersModel.setType(Model.Type.DM);
        
        dmModelItem = new ModelItem();
        dmModelItem.setType("interface");
        dmModelItem.setName("AddedInterface");

        developersModel.addModelItem(dmModelItem);
        
        metarepresenation.setAmModel(architectsModel);
        metarepresenation.setDmModel(developersModel);
        
        comparator = new Comparator();
        interfacesAddedCheck = new InterfacesAdded();
        
        comparator.add(interfacesAddedCheck);
    }


    public void testInterfacesAdded() {
        IReport report = comparator.evaluate();
        List<IDifference> differences = report.getDifferences();

        assertNotNull("There should be at least an empty list of differences",
                differences);
        
        int actualSize = differences.size();
        
        assertTrue("There must be one difference, but was: " + actualSize,
                actualSize == 1);
        
        IDifference.Status expected = IDifference.Status.ADDED;
        IDifference.Status actual = differences.get(0).getStatus();
        assertEquals("There should be a difference with the status added.",
                expected, actual);
    }
}
