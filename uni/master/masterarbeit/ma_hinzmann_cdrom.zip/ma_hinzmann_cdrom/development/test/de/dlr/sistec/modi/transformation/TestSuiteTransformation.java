/*
 * TestSuiteTransformation.java
 *
 * <Beschreibung>
 *
 * Created: Mar 17, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author Jan Hinzmann
 *
 */
public class TestSuiteTransformation extends TestCase {


    /**
     *
     * @return
     */
    public static Test suite() {
        TestSuite suite = new TestSuite("Transformation TestSuite");

        suite.addTestSuite(TestFileFinder.class);
        suite.addTestSuite(TestTransformation.class);

        return suite;
    }

}
