/*
 * ITreeWalker.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: ITreeWalker.java 187 2007-03-23 14:34:25Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.transformation;

import antlr.collections.AST;
import de.dlr.sistec.modi.metarepresentation.IModelItem;


public interface ITreeWalker {

    IModelItem walk(AST ast);

}
