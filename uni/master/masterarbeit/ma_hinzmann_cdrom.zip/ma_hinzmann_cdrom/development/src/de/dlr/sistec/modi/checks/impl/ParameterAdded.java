/*
 * ParameterAdded.java
 *
 * <Beschreibung>
 *
 * Created: Mar 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.IParameter;

/**
 * @author Jan Hinzmann
 * 
 */
public class ParameterAdded extends Check {

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.ICheck#check()
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();

        Map<IModelElement, IModelElement> modifiedOperations 
            = getModifiedMember(currentDifferences);

        for (IModelElement amElement : modifiedOperations.keySet()) {

            List<IParameter> amParameters = ((IOperation) amElement)
                    .getParameters();
            
            List<IParameter> dmParameters = ((IOperation) modifiedOperations
                    .get(amElement)).getParameters();

            // compute the added members
            List<IParameter> addedParameters = new ArrayList<IParameter>();
            addedParameters.addAll(dmParameters);

            for (IParameter member : amParameters) {
                String amIdentifier = member.getIdentifier();

                for (IParameter addedParameter : dmParameters) {
                    String dmIdentifier = addedParameter.getIdentifier();

                    if (amIdentifier.equals(dmIdentifier)) {
                        addedParameters.remove(addedParameter);
                    }
                }
            }

            // now we have the added members for this interface

            for (IParameter parameter : addedParameters) {
                IDifference difference = new Difference();
                difference.setName(super.getName());
                difference.setSeverity(super.getSeverity());
                difference.setDescription("The parameter \""
                        + parameter.getIdentifier()
                        + "\" has been added to the method \""
                        + amElement.getIdentifier() + "\".");
                difference.setLayer(IDifference.Layer.PARAMETER);
                difference.setStatus(IDifference.Status.ADDED);
                difference.setParentElement(amElement);
                difference.setDMElement((IModelElement) parameter);
                results.add(difference);
            }

        }
        return results;
    }

    private Map<IModelElement, IModelElement> getModifiedMember(
            List<IDifference> differences) {
        Map<IModelElement, IModelElement> result 
            = new HashMap<IModelElement, IModelElement>();

        for (IDifference difference : differences) {
            if (difference.getLayer() == IDifference.Layer.MEMBER
                    && difference.getAMElement() instanceof IOperation
                    && difference.getDMElement() instanceof IOperation) {
                IModelElement amItem = difference.getAMElement();
                IModelElement dmItem = difference.getDMElement();

                result.put(amItem, dmItem);
            }
        }

        return result;
    }
}
