/*
 * Difference.java
 *
 * <Beschreibung>
 *
 * Created: Mar 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.evaluation.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;

/**
 * @author Jan Hinzmann
 * 
 */
public class Difference implements IDifference {

    private String name;

    private String description;
    
    private Layer layer;

    private Status status;
    
    private Severity severity;

    private IModelElement amElement;

    private IModelElement dmElement;
    
    private IModelElement parentElement;
    
    private List<IDifference> subDifferences;

    public Difference() {
        this.name = "";
        this.description = "";
        this.layer = Layer.UNDEFINED;
        this.status = Status.UNDEFINED;
        this.amElement = new ModelItem();
        this.dmElement = new ModelItem();
        this.parentElement = new ModelItem();
        this.subDifferences = new ArrayList<IDifference>();
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param newName
     *            the name to set
     */
    public void setName(final String newName) {
        this.name = newName;
    }

    
    
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(final String newDescription) {
        this.description = newDescription;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#getAMElement()
     */
    public IModelElement getAMElement() {
        return amElement;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#getDMElement()
     */
    public IModelElement getDMElement() {
        return dmElement;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#getLayer()
     */
    public Layer getLayer() {
        return layer;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#getStatus()
     */
    public Status getStatus() {
        return status;
    }

    
    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.evaluation.IDifference#getSeverity()
     */
    public Severity getSeverity() {
        return this.severity;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.evaluation.IDifference#setSeverity(de.dlr.sistec
     *          .modi.evaluation.IDifference.Severity)
     */
    public void setSeverity(final Severity newSeverity) {
        this.severity = newSeverity;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#setAMElement(de.dlr.sistec
     *      .modi.metarepresentation.IModelElement)
     */
    public void setAMElement(final IModelElement newAMElement) {
        this.amElement = newAMElement;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#setDMElement(de.dlr.sistec
     *      .modi.metarepresentation.IModelElement)
     */
    public void setDMElement(final IModelElement newDMElement) {
        this.dmElement = newDMElement;
    }

    
    
    /**
     * @return the parentElement
     */
    public IModelElement getParentElement() {
        return parentElement;
    }

    /**
     * @param parentElement the parentElement to set
     */
    public void setParentElement(final IModelElement newParentElement) {
        this.parentElement = newParentElement;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#setLayer(de.dlr.sistec.modi
     *      .checks.IDifference.Layer)
     */
    public void setLayer(final Layer newLayer) {
        this.layer = newLayer;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.IDifference#setStatus(de.dlr.sistec.modi
     *      .checks.IDifference.Status)
     */
    public void setStatus(final Status newStatus) {
        this.status = newStatus;
    }

    
    
    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.evaluation.IDifference#addSubDifference(de.dlr
     *          .sistec.modi.evaluation.IDifference)
     */
    public void addSubDifference(IDifference subdifference) {
        this.subDifferences.add(subdifference);
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.evaluation.IDifference#getSubDifferences()
     */
    public List<IDifference> getSubDifferences() {
        return subDifferences;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "{ name: " + name + ", layer:" + layer + ", status:" + status
                + ", am:" + amElement.getIdentifier() + ", dm:"
                + dmElement.getIdentifier() + ", description: " + description 
                + ", severity: " + severity + "}";
    }

}
