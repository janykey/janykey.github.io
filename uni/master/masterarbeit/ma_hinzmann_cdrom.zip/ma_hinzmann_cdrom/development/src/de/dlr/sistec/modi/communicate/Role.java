/*
 * Role.java
 *
 * <Beschreibung>
 *
 * Created: May 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.communicate;

/**
 * @author Jan Hinzmann
 *
 */
public class Role {

    private String name;
    private String email;
    
    
    public Role(final String newName, final String newEmail) {
        name = newName;
        email = newEmail;
    }


    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }


    /**
     * @param newEmail the email to set
     */
    public void setEmail(final String newEmail) {
        email = newEmail;
    }


    /**
     * @return the name
     */
    public String getName() {
        return name;
    }


    /**
     * @param name the name to set
     */
    public void setName(final String newName) {
        name = newName;
    }

    
    public String toString() {
        return "R(n:" + name + ", @:" + email + ")";
    }
}
    
