/*
 * IParser.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: IParser.java 187 2007-03-23 14:34:25Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import java.io.File;

import antlr.collections.AST;

/**
 * <p>
 * The parser parses a file and genereates an abstract syntax tree from it.
 * </p>
 */
public interface IParser {

    AST getAST(File fileName);
}
