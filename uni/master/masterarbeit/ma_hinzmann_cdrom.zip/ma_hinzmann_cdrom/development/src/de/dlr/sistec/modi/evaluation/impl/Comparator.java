/*
 * Comparator.java
 *
 * <Beschreibung>
 *
 * Created: Feb 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Comparator.java 180 2007-03-21 14:23:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.evaluation.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import de.dlr.sistec.modi.checks.ICheck;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.impl.Report;

/**
 * Evaluates the checks and adds the resulting differences to the overall
 * differences.
 */
public final class Comparator implements IComparator {

    private List<ICheck> checks;

    
    public Comparator() {
        checks = new ArrayList<ICheck>();
    }

    public void add(ICheck check) {
        checks.add(check);
    }

    public List<ICheck> getChecks() {
        return Collections.unmodifiableList(checks);
    }
    
    /**
     * Evaluates all known Checks in the order they have been added.
     */
    public IReport evaluate() {
        IReport result = new Report();
        result.setDate(new GregorianCalendar().getTime());

        for (ICheck check : checks) {
            List<IDifference> differences = check
                    .check(result.getDifferences());
            result.addAll(differences);
        }

        return result;
    }
}
