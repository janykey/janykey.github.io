/*
 * Constant.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Variable.java 307 2007-05-22 11:29:44Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IVariable;

public class Variable extends Member implements IModelElement, IVariable {

    private String value;

    public Variable() {
        super();
        value = "";
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IVariable#getValue()
     */
    public String getValue() {
        return value;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *          .IVariable#setValue(java.lang.String)
     */
    public void setValue(final String newValue) {
        this.value = newValue;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *          .IVariable#equals(java.lang.Object)
     */
    public boolean equals(Object other) {
        boolean result = false;

        if (!(other instanceof Variable)) {
            return false;
        }

        boolean superEquals = super.equals(other);
        IVariable otherVariable = (IVariable) other;

        boolean valueEqual = this.value.equals(otherVariable.getValue());
            
        result = (superEquals && valueEqual);

        return result;
    }
    
    public int hashCode() {
        int result = 7;
        result = 31 * result + super.hashCode();
        result = 31 * result + (null == value ? 0 : value.hashCode());
        return result;
    }

    
    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IVariable#toString()
     */
    public String toString() {
        String modifierString = "";
        for (String tmp : this.modifiers) {
            modifierString += tmp + " ";
        }
        
        String valueString = "";
        if (this.value.length() > 0) {
            valueString += " = " + this.value + ";";
        }
        
        return (modifierString + " " + this.type.getIdentifier() + " " 
                + this.getIdentifier() + valueString).trim();
    }

   
}
