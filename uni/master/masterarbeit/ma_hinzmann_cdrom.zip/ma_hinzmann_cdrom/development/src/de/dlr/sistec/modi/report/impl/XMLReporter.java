/*
 * XMLReporter.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: XMLReporter.java 147 2007-03-17 20:49:01Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.report.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import de.dlr.sistec.modi.Config;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.IReporter;

/**
 * @author Jan Hinzmann
 * 
 */
public class XMLReporter implements IReporter {

    private String filename;

    /**
     * this has to be instantiated through the ReporterFactory.
     */
    protected XMLReporter() {

    }

    /**
     * setting the filename will store the report at this location. if this is
     * not set, the filelocation from the config will be used.
     * 
     * @param file
     */
    public void setFilename(String file) {
        this.filename = file;
    }

    /**
     * Generates the XML representation of the given report and writes it to the
     * file configured with "MoDi.XMLReportFile.Name".
     * 
     * @see de.dlr.sistec.modi.evaluation.IReporter#report()
     */
    public void report(IReport report) {
        StringBuffer result = generateXML(report);
        writeFile(result);
    }

    /**
     * Returns the XML representation of a report.
     * 
     * @param report
     *            An IReport
     * @return the XML representation of the given report.
     */
    public StringBuffer getReportAsXML(IReport report) {
        return generateXML(report);
    }

    private StringBuffer generateXML(IReport report) {
        StringBuffer result = new StringBuffer();

        result.append("<?xml version=\"1.0\"?>\n");

        result.append("<?xml-stylesheet type=\"text/xsl\" "
                + "href=\"modi2html.xsl\" ?>\n");

        result.append("<report name=\"MoDi Report v0.1\">\n");

        result.append("  <meta>\n");

        result.append("    <date value=\"" + report.getDate() + "\"/>\n");

        result.append("    <differencecount>\n" + "        <all>"
                + report.getDifferences().size() + "</all>\n"
                + "        <high>"
                + getSeverityCount(report, IDifference.Severity.HIGH)
                + "</high>\n" + "        <medium>"
                + getSeverityCount(report, IDifference.Severity.MEDIUM)
                + "</medium>\n" + "        <low>"
                + getSeverityCount(report, IDifference.Severity.LOW)
                + "</low>\n" + "    </differencecount>\n");

        result.append("    <architect>" + report.getArchitect()
                + "    </architect>\n");

        result.append("    <developer>" + report.getDeveloper()
                + "    </developer>\n");

        result.append("    <architectsversion>"
                + report.getArchitectsModelVersion()
                + "    </architectsversion>\n");

        result.append("    <developersversion>"
                + report.getDevelopersModelVersion()
                + "    </developersversion>\n");

        // TODO add more metadata
        result.append("     <projectname>" + report.getProjectName()
                + "    </projectname>");

        result.append("  </meta>\n");

        result.append("  <differences>\n");
        int i = 0;
        for (IDifference difference : report.getDifferences()) {
            i++;
            result.append("    <difference check=\"" + difference.getName()
                    + "\">\n");
            result.append("      <description>" + difference.getDescription()
                    + "</description>\n");
            result.append("      <amelement name=\""
                    + difference.getAMElement().getIdentifier() + "\"/>\n");
            result.append("      <dmelement name=\""
                    + difference.getDMElement().getIdentifier() + "\"/>\n");
            result.append("      <parent name=\""
                    + difference.getParentElement().getIdentifier() + "\"/>\n");
            result.append("      <status value=\"" + difference.getStatus()
                    + "\"/>\n");
            result.append("      <layer value=\"" + difference.getLayer()
                    + "\"/>\n");
            result.append("      <severity>" + difference.getSeverity()
                    + "</severity>\n");
            // für parent: achtung, kann null sein
            result.append("    </difference>\n");
        }
        result.append("  </differences>\n");
        result.append("</report>\n");

        return result;
    }

    private int getSeverityCount(IReport report, IDifference.Severity severity)
    {
        int result = 0;

        List<IDifference> differences = report.getDifferences();
        for (IDifference item : differences) {
            if (item.getSeverity() == severity) {
                result++;
            }
        }

        return result;
    }

    private void writeFile(StringBuffer reportResult) {
        String fileName;
        String fileLocation;
        FileWriter writer;

        try {
            fileName = Config.getStringProperty("MoDi.XMLReportFile.Name");
            fileLocation = Config
                    .getStringProperty("MoDi.XMLReportFile.Location");

            // does the directory for the report exist?
            if (filename != null) {
                fileLocation = filename;
            }
            File file = new File(fileLocation);
            if (!file.isDirectory()) {
                throw new MoDiException("the directory configured for the "
                        + "report does not exist.");
            }

            writer = new FileWriter(fileLocation + "/" + fileName);
            writer.write(reportResult.toString());
            writer.close();

            // also copy the xsl aside to the report.xml reusing fileLocation
            String xslLocation = Config.getStringProperty("MoDi.XSL.Location");
            File xslIn = new File(xslLocation);
            File xslOut = new File(fileLocation + "/" + "modi2html.xsl");
            FileInputStream fis = new FileInputStream(xslIn);
            FileOutputStream fos = new FileOutputStream(xslOut);
            byte[] buf = new byte[1024];
            int i = 0;
            while ((i = fis.read(buf)) != -1) {
                fos.write(buf, 0, i);
            }
            fis.close();
            fos.close();

        } catch (MoDiException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
