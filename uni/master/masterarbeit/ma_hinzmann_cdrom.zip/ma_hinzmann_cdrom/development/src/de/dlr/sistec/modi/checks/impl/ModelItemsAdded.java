/*
 * ModelItemsAdded.java
 *
 * <Beschreibung>
 *
 * Created: May 22, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

/**
 * @author Jan Hinzmann
 * 
 */
public class ModelItemsAdded extends Check {

    
    /**
     * Checks for ModelItems added to the Model. That is, an ModelItem is in the
     * list of modelitems in the developers model (DM) but not in the list of
     * the model items in the architects model (AM). Therefore all model items
     * in the DM are suspicious and copied to the list of added model items. 
     * Then the model items found also to be in the DM and in the AM are removed
     *  from the list of suspicious model items leaving the added model items in
     *  the list.
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();

        List<IModelElement> amModelElements = super.getAMModelElements();
        List<IModelElement> dmModelElements = super.getDMModelElements();

        List<IModelElement> addedModelElements = new ArrayList<IModelElement>();

        // all modelelements in the DM are suspicious
        addedModelElements.addAll(dmModelElements);

        for (IModelElement dmItem : dmModelElements) {
            String dmIdentifier = ((IModelItem) dmItem).getNamespace() + "."
                    + ((IModelItem) dmItem).getIdentifier();

            for (IModelElement amItem : amModelElements) {
                String amIdentifier = ((IModelItem) amItem).getNamespace()
                        + "." + ((IModelItem) amItem).getIdentifier();

                // finding the dmModelElements in the amModelElements lets us
                // know that it's there. So it's not added and we can remove it.
                if ((amIdentifier.equals(dmIdentifier))) {
                    addedModelElements.remove(dmItem);
                    break;
                }
            }
        }

        for (IModelElement item : addedModelElements) {
            IDifference difference = new Difference();
            difference.setName(super.getName());
            difference.setSeverity(super.getSeverity());
            difference.setDescription("The " + ((IModelItem) item).getType()
                    + " \"" + item.getIdentifier()
                    + "\" has been added to the model.");
            difference.setLayer(IDifference.Layer.MODELITEM);
            difference.setStatus(IDifference.Status.ADDED);
            difference.setDMElement(item);
            results.add(difference);
        }

        return results;
    }
}
