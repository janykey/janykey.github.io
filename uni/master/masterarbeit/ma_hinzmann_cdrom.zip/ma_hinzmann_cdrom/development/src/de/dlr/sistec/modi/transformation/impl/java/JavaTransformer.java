/*
 * Transformer.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: JavaTransformer.java 317 2007-05-22 15:12:50Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation.impl.java;

import java.io.File;
import java.util.List;

import antlr.collections.AST;
import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.transformation.IParser;
import de.dlr.sistec.modi.transformation.ITransformer;
import de.dlr.sistec.modi.transformation.ITreeWalker;

public class JavaTransformer implements ITransformer {

//    private final static Logger LOGGER = Logger.getLogger("MoDiLogger");
    
    public JavaTransformer() {
    }


    public IModel transform(List<File> modelFileList) throws MoDiException {
        IModel result = new Model();
        IModelItem item = null;

        IParser joda = new JavaParser();
        ITreeWalker luke = new ASTtoMetaRepresentationTransformer();
        
        for (File file : modelFileList) {
            //TODO remove debug
//           LOGGER.info("parsing file: " + file.getAbsolutePath());
            AST ast = joda.getAST(file);// parse the file
            item = luke.walk(ast); // build a ModelItem from the AST
            result.addModelItem(item); // add it to the model
        }
        
        return result;
    }
}
