/*
 * HTMLReporter.java
 *
 * <Beschreibung>
 *
 * Created: May 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.report.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.Writer;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import de.dlr.sistec.modi.Config;
import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.report.IReport;

/**
 * @author Jan Hinzmann
 * 
 */
public class HTMLReporter extends XMLReporter {

    /**
     * this has to be instantiated through the ReporterFactory.
     */
    protected HTMLReporter() {

    }

    /**
     * @see de.dlr.sistec.modi.report.impl.XMLReporter
     *          #report(de.dlr.sistec.modi.report.IReport)
     */
    @Override
    public void report(IReport report) {
        try {

            File xsl = new File(Config.getStringProperty("MoDi.XSL.Location"));

            String location = Config
                    .getStringProperty("MoDi.XMLReportFile.Location");

            String name = Config.getStringProperty("MoDi.XMLReportFile.Name");
            File xml = new File(location + name);

            File html = new File(Config
                    .getStringProperty("MoDi.HTMLReportFile.Path"));

            //this generates and writes the xml file to its configured location 
            super.report(report);

            transform(xsl, xml, html);
      
        } catch (MoDiException e) {
            System.out.println("Something's wrong with the Config:\n"
                    + e.getMessage());
            System.exit(1);
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (TransformerConfigurationException e) {
            System.out.println(e.getMessage());
        } catch (TransformerException e) {
            System.out.println(e.getMessage());
        }
    }

    private void transform(File xsl, File xml, File html)
            throws FileNotFoundException, TransformerException {

        TransformerFactory transformerFactory = TransformerFactory
                .newInstance();

        Source xslSource = new StreamSource(xsl);
        Source xmlSource = new StreamSource(xml);
        Result outputTarget = new StreamResult(new FileOutputStream(html));
        Transformer transformer = transformerFactory.newTransformer(xslSource);

        transformer.transform(xmlSource, outputTarget);

    }

}
