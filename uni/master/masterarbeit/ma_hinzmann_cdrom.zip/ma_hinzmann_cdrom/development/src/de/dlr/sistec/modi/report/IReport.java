/*
 * IReport.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: IReport.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.report;

import java.util.Date;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;

public interface IReport {

    void setDate(Date date);
    Date getDate();
    
    void setProjectName(String projectName);
    String getProjectName();
    
    void setArchitect(String name);
    String getArchitect();
    
    void setDeveloper(String name);
    String getDeveloper();
    
    void setArchitectsModelVersion(String version);
    String getArchitectsModelVersion();
    
    void setDevelopersModelVersion(String version);
    String getDevelopersModelVersion();
    
    void add(IDifference item);

    void addAll(List<IDifference> element);
    
    List<IDifference> getDifferences();
}
    
