/*
 * IModelElement.java
 *
 * <Beschreibung>
 *
 * Created: Mar 21, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

/**
 * This is a  interface to handle model elements during the evaluation
 * phase.
 * @author Jan Hinzmann
 *
 */
public interface IModelElement {

    String getIdentifier();
    
}
