/*
 * IModelItem.java
 *
 * <Beschreibung>
 *
 * Created: Mar 18, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import java.util.List;

/**
 * @author Jan Hinzmann
 *
 */
public interface IModelItem {

    void setModifiers(List<String> modifiers);
    List<String> getModifiers();
    
    void setType(String type);
    String getType();
    
    void setNamespace(String namespace);
    String getNamespace();
    
    void addImport(String importStatement);
    List<String> getImports();
    
    void setName(String newName);
    String getName();

    String getIdentifier();
    
    void addExtendee(IModelItem extendee);
    void setExtendees(List<IModelItem> extendees);
    List<IModelItem> getExtendees();

    void addMember(IMember member);
    List<IMember> getMembers();

}
