/*
 * AddedPrivateMembersInClasses.java
 *
 * <Beschreibung>
 *
 * Created: May 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.IVariable;
import de.dlr.sistec.modi.metarepresentation.impl.Model;

/**
 * This check searches for additional Members that have the modifier private.
 * 
 * @author Jan Hinzmann
 */
public class AddedPrivateMembersInClasses extends Check {

    /**
     * Checks for private Members that have been added to Classes. Note that
     * interfaces do not have private members.
     * 
     * @param The
     *            list of current Differences that have been already found.
     * @return A list of differences found by this check.
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {

        List<IDifference> result = new ArrayList<IDifference>();

        List<IModelItem> amClasses = getClasses(Model.Type.AM);
        List<IModelItem> dmClasses = getClasses(Model.Type.DM);

        for (IModelItem amItem : amClasses) {

            for (IModelItem dmItem : dmClasses) {

                if (amItem.getIdentifier().equals(dmItem.getIdentifier())) {

                    List<IMember> privateAMClassMember = 
                        new ArrayList<IMember>();

                    privateAMClassMember.addAll(getPrivateMember(amItem));

                    List<IMember> privateDMClassMember = 
                        new ArrayList<IMember>();
                    privateDMClassMember.addAll(getPrivateMember(dmItem));

                    // we now have the following information at the hand:
                    // amItem, privateAMClassMember
                    // dmItem, privateDMClassMember
                    List<IMember> addedMembers = checkForAddedPrivateMembers(
                            privateAMClassMember, privateDMClassMember);

                    for (IMember item : addedMembers) {
                        String type = "member";
                        IModelItem typeItem = item.getType();
                        if (typeItem instanceof IOperation) {
                            type = "operation";
                        }
                        if (typeItem instanceof IVariable) {
                            type = "variable";
                        }
                        IDifference difference = new Difference();
                        difference.setDescription("The private "
                                + type + " "
                                + item.getIdentifier() + " has been added to "
                                + "the " + dmItem.getType() + " "
                                + dmItem.getIdentifier());
                        difference.setDMElement((IModelElement) item);
                        difference.setParentElement((IModelElement) dmItem);
                        difference.setSeverity(super.getSeverity());
                        difference.setLayer(IDifference.Layer.MEMBER);
                        difference.setStatus(IDifference.Status.ADDED);

                        result.add(difference);
                    }
                }
            }
        }
        return result;
    }

    private List<IMember> checkForAddedPrivateMembers(
            List<IMember> privateAMClassMember,
            List<IMember> privateDMClassMember) {

        List<IMember> addedMembers = new ArrayList<IMember>();
        addedMembers.addAll(privateDMClassMember);

        for (IMember dmMember : privateDMClassMember) {

            for (IMember amMember : privateAMClassMember) {

                if (dmMember.getIdentifier().equals(amMember.getIdentifier())) {
                    addedMembers.remove(dmMember);// leaving the added ones
                }

            }
        }
        return addedMembers;
    }

}
