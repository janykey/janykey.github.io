/*
 * IComparator.java
 *
 * <Beschreibung>
 *
 * Created: Feb 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: IComparator.java 213 2007-03-28 16:59:09Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.evaluation;

import java.util.List;

import de.dlr.sistec.modi.checks.ICheck;
import de.dlr.sistec.modi.report.IReport;

/**
 * Evaluates the rules and adds resulting ReportItems to the report.
 */
public interface IComparator {

    void add(ICheck check);

    List<ICheck> getChecks();
    
    IReport evaluate();
    

}
