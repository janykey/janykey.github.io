/*
 * InterfacesRemoved.java
 *
 * <Beschreibung>
 *
 * Created: May 22, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;

/**
 * @author Jan Hinzmann
 *
 */
public class InterfacesRemoved extends ModelItemsRemoved {

    /**
     * @see de.dlr.sistec.modi.checks.impl.ModelItemsModified
     *  #check(java.util.List)
     */
    @Override
    public List<IDifference> check(List<IDifference> currentDifferences) {
        super.reduceProblemSpaceToInterfaces();
        return super.check(currentDifferences);
    }
}
