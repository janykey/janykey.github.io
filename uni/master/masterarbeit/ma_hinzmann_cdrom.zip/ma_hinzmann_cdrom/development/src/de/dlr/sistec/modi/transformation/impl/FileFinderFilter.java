/*
 * FileFinderFilter.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: FileFinderFilter.java 187 2007-03-23 14:34:25Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.transformation.impl;

import java.io.File;
import java.io.FilenameFilter;

public class FileFinderFilter implements FilenameFilter {

    private String pattern = null;

    private FileFinderFilter() {
    } // only Filters for files and patterns please (see below)

    public FileFinderFilter(final String newPattern) {

        this.pattern = "*." + newPattern;
    }

    public boolean accept(File parentDir, String filename) {
        boolean accepted = false;
        
        //"*.java" gets {"*", "java"}
        String[] filenameParts = pattern.split("\\.");

        if (filename.endsWith(filenameParts[1])) {
            accepted = true;
        }

        return accepted;
    }

}
