/*
 * IFileFinder.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: IFileFinder.java 147 2007-03-17 20:49:01Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import java.io.File;
import java.util.List;

import de.dlr.sistec.modi.exception.MoDiException;

public interface IFileFinder {

    /**
     * Finds files for a given rootDir and a fileExtensionPattern. e.g.
     * <tt>MyFileFinder.findFiles(newFile("/home/jan/modi"), "*.java");</tt>
     *
     * @param rootDir
     *            The directory where to find the files.
     * @param fileExtension
     *            A pattern matching file extensions.
     * @return A list of files which have been found in the rootDir matching the
     *         given file extension.
     * @throws MoDiException
     */
    List<File> findFiles(File rootDir, String fileExtension)
            throws MoDiException;

}
