/*
 * MoDi.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: MoDi.java 373 2007-06-01 22:26:35Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import org.apache.commons.mail.EmailException;

import de.dlr.sistec.modi.checks.ICheck;
import de.dlr.sistec.modi.communicate.Communicator;
import de.dlr.sistec.modi.evaluation.IComparator;
import de.dlr.sistec.modi.evaluation.impl.Comparator;
import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;
import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.IReporter;
import de.dlr.sistec.modi.report.impl.ReporterFactory;
import de.dlr.sistec.modi.transformation.FileFinderFactory;
import de.dlr.sistec.modi.transformation.IFileFinder;
import de.dlr.sistec.modi.transformation.ITransformer;
import de.dlr.sistec.modi.transformation.TransformerFactory;

/**
 * MoDi means ModelDifferences.
 * 
 * <p>
 * The slogan is: <em>Transform! Compare! Communicate!</em> ;o) .
 * </p>
 * 
 * In MoDi we do the following:
 * <ol>
 * <li> set am root</li>
 * <li> set dm root</li>
 * <li> let the transformer set up the meta representation</li>
 * <li> compare the models using the meta representation</li>
 * <li> return the resulting report</li>
 * </ol>
 */
public class MoDi {

    private  static final Logger LOGGER = Logger.getLogger("MoDiLogger");

    public static enum ImportHandler {
        FILESYSTEM
    };

    public static enum PersistenceType {
        HSQLDB
    };

    public static enum Language {
        JAVA, PYTHON
    };

    public static enum ReportStyle {
        CONSOLE, XML, JUPITER, HTML
    };

    public static final String ARCHITECTSMODEL_NAME = "Architect's model tree";

    public static final String DEVELOPERSMODEL_NAME = "Developer's model tree";

    private List<File> amFiles;

    private List<File> dmFiles;

    private IMetaRepresentation metaRepresentation;

    public MoDi() {
        metaRepresentation = MetaRepresentation.getInstance();
    }

    public void setConfigFile(String fileLocation) {
        System.setProperty("MODICONFIG", fileLocation);
    }

    public String getConfigFile() {
        return System.getProperty("MODICONFIG");
    }

    // import___________________________________________________________________
    public void findArchitectsModelFiles(MoDi.ImportHandler importHandler,
            String modelRoot, String fileExtension) throws MoDiException {

        amFiles = findModelFiles(importHandler, modelRoot, fileExtension);
    }

    public void findDevelopersModelFiles(MoDi.ImportHandler importHandler,
            String modelRoot, String fileExtension) throws MoDiException {

        dmFiles = findModelFiles(importHandler, modelRoot, fileExtension);
    }

    private List<File> findModelFiles(MoDi.ImportHandler importHandler,
            String modelRoot, String fileExtension) throws MoDiException {

        IFileFinder finder = FileFinderFactory.create(importHandler);
        return finder.findFiles(new File(modelRoot), fileExtension);
    }

    // transform________________________________________________________________
    public void transformArchitectsModel(MoDi.Language language)
            throws MoDiException {
        if (amFiles == null) {
            throw new MoDiException("We have no model files, call "
                    + "findArchitectsModelFiles(...) first.");
        }

        IModel amModel = new Model();
        amModel.setType(Model.Type.AM);
        amModel = transformModel(amFiles, language);
        metaRepresentation.setAmModel(amModel);
    }

    public void transformDevelopersModel(MoDi.Language language)
            throws MoDiException {
        if (dmFiles == null) {
            throw new MoDiException("We have no model files, call "
                    + "findDevelopersModelFiles(...) first.");
        }

        IModel dmModel = new Model();
        dmModel.setType(Model.Type.DM);
        dmModel = transformModel(dmFiles, language);
        metaRepresentation.setDmModel(dmModel);
    }

    private IModel transformModel(List<File> modelFiles, MoDi.Language language)
            throws MoDiException {

        ITransformer transformer = TransformerFactory.create(language);
        IModel result = transformer.transform(modelFiles);
        return result;
    }

    // evaluate_________________________________________________________________
    public IReport evaluate() {

        IComparator comparator = new Comparator();
        setupRules(comparator);
        LOGGER.info("all Checks in Rules: " + comparator.getChecks().size());
        return comparator.evaluate();
    }

    private void setupRules(final IComparator comparator) {
        List<String> ruleConfig;
        for (int i = 1; (ruleConfig = Config.getRuleProperties(i)) != null; i++)
        {
            setupRule(comparator, ruleConfig);
        }
    }

    private void setupRule(final IComparator comparator,
            final List<String> ruleConfig) {

        try {
            String checks = null;
            String name = null;
            String severity = null;

            for (String string : ruleConfig) {
                LOGGER.info(string + "=" + Config.getStringProperty(string));
                
                if (string.endsWith("Name")) {
                    name = Config.getStringProperty(string);
                }
                if (string.endsWith("Checks")) {
                    checks = Config.getStringProperty(string);
                }
                if (string.endsWith("Severity")) {
                    severity = Config.getStringProperty(string);
                }
            }

            String packageName = Config.getStringProperty("MoDi.ChecksPackage");
            List<String> classNames = new ArrayList<String>();

            StringTokenizer tokenizer = new StringTokenizer(checks, ",");

            while (tokenizer.hasMoreTokens()) {
                classNames.add(tokenizer.nextToken().trim());
            }
            
            // adding rules
            for (String tmpClassName : classNames) {
                Class check = Class.forName(packageName + "." + tmpClassName);
                ICheck addrule = (ICheck) check.newInstance();
                addrule.setName(name);
                addrule.setSeverity(severity);
                comparator.add(addrule);
            }

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InstantiationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (MoDiException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
//  report___________________________________________________________________
    public void report(IReport report, MoDi.ReportStyle reportStyle) {

        IReporter reporter = ReporterFactory.create(reportStyle);
        reporter.report(report);

    }
    
//  communicate_______________________________________________________________
    public void communicate(IReport report) throws MoDiException, EmailException
    {
        
        Communicator communicator = new Communicator();
        communicator.communicate(report);
    }

    /**
     * A Client implementation.
     * 
     * @param args
     *            The parameters are not used.
     */
    public static void main(final String[] args) {
        long start = -System.currentTimeMillis();
        Logger logger = Logger.getLogger("MoDiLogger");
        logger.info("starting up ...");

        MoDi modi = new MoDi();

        try {
            String amRoot;
            String dmRoot;

            if ((args.length != 3)) {
                usage();
            }

            System.setProperty("MODICONFIG", args[0]);
            amRoot = args[1];
            dmRoot = args[2];

            logger.info("finding model files");
            modi.findArchitectsModelFiles(MoDi.ImportHandler.FILESYSTEM,
                    amRoot, "java");
            modi.findDevelopersModelFiles(MoDi.ImportHandler.FILESYSTEM,
                    dmRoot, "java");

            logger.info("transforming models into metamodel");
            modi.transformArchitectsModel(MoDi.Language.JAVA);
            modi.transformDevelopersModel(MoDi.Language.JAVA);

            logger.info("evaluating the differences.");
            IReport report = modi.evaluate();
            String projectName = 
                Config.getStringProperty("MoDi.Meta.Project.Name");
            
            report.setProjectName(projectName);
            
            report.setArchitect(
                    Config.getStringProperty("MoDi.Meta.Architect"));
            
            report.setArchitectsModelVersion(projectName + ": " + amRoot);
            
            report.setDeveloper(
                    Config.getStringProperty("MoDi.Meta.Developer"));
            
            report.setDevelopersModelVersion(projectName + ": " + dmRoot);

            logger.info("reporting");
           // modi.report(report, MoDi.ReportStyle.CONSOLE);
//            modi.report(report, MoDi.ReportStyle.XML);
            modi.report(report, MoDi.ReportStyle.HTML); // html implies xml
            
            //logger.info("communicating");
            //modi.communicate(report); // communication needs html report
            
            logger.info(report.getDifferences().size() + " differences found.");
            long duration = start + System.currentTimeMillis();
            logger.info("Done (" + duration + " ms).");

        } catch (MoDiException e) {
            System.out.println(e.getMessage());
            
//        } catch (EmailException e) {
//            System.out.println(e.getMessage());
//            e.printStackTrace();

        } catch (Exception e) {                        
            usage();
        }
    }

    public static void usage() {
        System.out.println("Usage: java -jar CONFIGFILE AM DM");
        System.exit(1);
    }
}
