/*
 * TerminalReporter.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: TerminalReporter.java 187 2007-03-23 14:34:25Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.report.impl;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.IReporter;


public class TerminalReporter implements IReporter {

    /**
     * this has to be instantiated through the ReporterFactory.
     */
    protected TerminalReporter() {
        
    }
    
    public void report(IReport report) {
        String result = "--- MoDi Report v0.1 ---\n";

        result += report.getDate() + "\n";

        for (IDifference item : report.getDifferences()) {
        
            IModelElement parent = item.getParentElement();
            String parentIdentifier;
            if (parent == null) {
                parentIdentifier = "-";
            } else {
                parentIdentifier = parent.getIdentifier();
            }
            
            result += "\nDifference (" + item.getName() + "):\n" 
                + " Description: " + item.getDescription() + "\n"
                + " Details: \n"
                + "   in AM     : " + item.getAMElement().getIdentifier() + "\n"
                + "   in DM     : " + item.getDMElement().getIdentifier() + "\n"
                + "   belongs to: " + parentIdentifier + "\n"
                + "   status    : " + item.getStatus() + "\n"
                + "   severity  : " + item.getSeverity() + "\n";
        }

        result += "\n--- end of report ---\n";
        System.out.print(result);
    }
}
