/*
 * IDifference.java
 *
 * <Beschreibung>
 *
 * Created: Mar 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.evaluation;

import java.util.List;

import de.dlr.sistec.modi.metarepresentation.IModelElement;

/**
 * @author Jan Hinzmann
 * 
 */
public interface IDifference {

    enum Status {
        ADDED, REMOVED, MODIFIED, UNDEFINED
    }

    enum Layer {
        MODEL, MODELITEM, MEMBER, PARAMETER, UNDEFINED
    }
    
    enum Severity {
        LOW, MEDIUM, HIGH
    }

    void setName(final String newName);
    String getName();

    void setStatus(final Status newStatus);
    Status getStatus();

    void setLayer(final Layer newLayer);
    Layer getLayer();

    void setSeverity(final Severity severity);
    Severity getSeverity();
    
    void setAMElement(final IModelElement newAMElement);
    IModelElement getAMElement();

    void setDMElement(final IModelElement newDMElement);
    IModelElement getDMElement();
    
    void setParentElement(final IModelElement newParentElement);
    IModelElement getParentElement();

    void setDescription(final String newDescription);
    String getDescription();
    
    void addSubDifference(final IDifference subdifference);
    List<IDifference> getSubDifferences();
}
