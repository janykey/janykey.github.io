/*
 * Member.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Member.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

/**
 * super class for operations and constants.
 * 
 * @author jan hinzmann
 * 
 */
public abstract class Member implements IModelElement, IMember {

    protected List<String> modifiers;

    protected IModelItem type;

    protected String namespace;

    protected String name;

    public Member() {
        super();
        modifiers = new ArrayList<String>();
        type = new ModelItem();
        namespace = "";
        name = "";
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl.IMember#getModifiers()
     */
    public List<String> getModifiers() {
        return modifiers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IMember#setModifiers(java.util.List)
     */
    public void setModifiers(final List<String> newModifiers) {
        this.modifiers = newModifiers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IMember#addModifier(java.lang.String)
     */
    public void addModifier(final String newModifier) {
        this.modifiers.add(newModifier);
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl.IMember#getType()
     */
    public IModelItem getType() {
        return type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IMember#setType(de.dlr.sistec.modi.metarepresentation.IModelItem)
     */
    public void setType(final IModelItem newReturnType) {
        this.type = newReturnType;
    }

    /**
     * @param namespace
     *            the namespace to set
     */
    public void setNamespace(final String newNamespace) {
        this.namespace = newNamespace;
    }

    /**
     * @return the namespace
     */
    public String getNamespace() {
        return namespace;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IMember#setName(java.lang.String)
     */
    public void setName(final String newName) {
        this.name = newName;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl.IMember#getIdentifier()
     */
    public String getIdentifier() {
        return namespace + "." + name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IMember#equals(java.lang.Object)
     */
    public boolean equals(Object other) {
        boolean result = false;

        if (!(other instanceof IMember)) {
            return false;
        }

        IMember otherMember = (IMember) other;
        // Strings
        boolean identifiersEqual = this.getIdentifier().equals(
                otherMember.getIdentifier());

        // Lists
        boolean modifiersSizeEqual = (this.modifiers.size() == otherMember
                .getModifiers().size());

        boolean modifiersContainsEqual = this.modifiers.containsAll(otherMember
                .getModifiers());

        boolean modifiersEqual = (modifiersContainsEqual && modifiersSizeEqual);

        boolean typesEqual = this.type.equals(otherMember.getType());

        result = (identifiersEqual && modifiersEqual && typesEqual);

        return result;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result
                + ((modifiers == null) ? 0 : modifiers.hashCode());
        result = PRIME * result + ((name == null) ? 0 : name.hashCode());
        result = PRIME * result
                + ((namespace == null) ? 0 : namespace.hashCode());
        result = PRIME * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }

}
