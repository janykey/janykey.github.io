/*
 * RuleTemplate.java
 *
 * <Beschreibung>
 *
 * Created: Feb 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: RuleTemplate.java 170 2007-03-21 09:29:45Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.checks.ICheck;
import de.dlr.sistec.modi.evaluation.IDifference;

/**
 * This class serves as template for the development of new checks.
 * You can simply copy and rename it. Then go ahead and implement your check.
 * @author Jan Hinzmann
 */
public class CheckTemplate extends Check implements ICheck {



    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();
     
        // ----- contents area -------------------------------------------------

        // your migthy code here
        
        // ----- contents area end ---------------------------------------------
        
        return results;
    }

}
