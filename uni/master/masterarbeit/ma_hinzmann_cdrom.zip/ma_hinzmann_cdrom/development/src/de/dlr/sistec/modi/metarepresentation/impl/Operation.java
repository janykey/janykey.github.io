/*
 * Operation.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Operation.java 307 2007-05-22 11:29:44Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.IParameter;

public class Operation extends Member implements IModelElement, IOperation {

    private List<IParameter> parameters;

    public Operation() {
        super();
        parameters = new ArrayList<IParameter>();
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IOperation#addParameter(de.dlr.sistec.modi.metarepresentation.impl
     * .Parameter)
     */
    public void addParameter(IParameter parameter) {
        this.parameters.add(parameter);
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IOperation#getParameters()
     */
    public List<IParameter> getParameters() {
        return parameters;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IOperation#equals(java.lang.Object)
     */
    public boolean equals(Object other) {
        boolean result = false;

        if (!(other instanceof Operation)) {
            return false;
        }

        boolean superEquals = super.equals(other);
        IOperation otherOperation = (IOperation) other;

        boolean parametersSizeEqual = this.parameters.size() == otherOperation
                .getParameters().size();

        boolean parametersContainsEqual = this.parameters
                .containsAll(otherOperation.getParameters());
        
       result = (superEquals && parametersSizeEqual && parametersContainsEqual);

        return result;
    }
    
    public int hashCode() {
        int result = 7;
        result = 31 * result + super.hashCode();
        result = 31 * result + (null == parameters ? 0 : parameters.hashCode());
        return result;
    }


    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IOperation#toString()
     */
    public String toString() {
        String modifier = "";
        String type = "";
        String identifier = "";
        String parameter = "";

        for (String tmp : this.modifiers) {
            if (tmp != null) {
                modifier += tmp + " ";
            }
        }
        
        if (this.type != null) {
            type += this.type.getIdentifier();
        }
        
        identifier += this.getIdentifier();
        
        for (IParameter tmp : this.parameters) {
            parameter += tmp.getType().getIdentifier() + " "
                    + tmp.getIdentifier() + ", ";
        }
        
        if (!this.parameters.isEmpty()) {
            parameter = parameter.substring(0, (parameter
                    .length() - 2));
        }
        return (modifier + " " + type + " " + identifier 
                + "(" + parameter + ");").trim();
    }

   
}
