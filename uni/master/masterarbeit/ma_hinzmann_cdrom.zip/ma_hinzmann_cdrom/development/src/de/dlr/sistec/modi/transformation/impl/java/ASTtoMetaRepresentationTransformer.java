/*
 * ASTtoMetaRepresentationTransformer.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
*$Id: ASTtoMetaRepresentationTransformer.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation.impl.java;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import java.util.logging.Logger;
import java5parsingCheckstyleGrammar.GeneratedJavaTokenTypes;

import antlr.collections.AST;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.IParameter;
import de.dlr.sistec.modi.metarepresentation.IVariable;
import de.dlr.sistec.modi.metarepresentation.impl.ModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.Operation;
import de.dlr.sistec.modi.metarepresentation.impl.Parameter;
import de.dlr.sistec.modi.metarepresentation.impl.Variable;
import de.dlr.sistec.modi.transformation.ITreeWalker;

public class ASTtoMetaRepresentationTransformer implements ITreeWalker {

    private static final Logger LOGGER = Logger.getLogger("MoDiLogger");

    private IModelItem modelItem;

    private IVariable memberVariable;

    private IOperation memberOperation;

    private IParameter parameter;

    private Stack<AST> preOrderStack;

    private Queue<AST> preOrderQueue;

    public ASTtoMetaRepresentationTransformer() {
    }

    public IModelItem walk(AST ast) {
        modelItem = new ModelItem();

        walkDepthFirst(ast);// walk the tree and fill the modelItem

        return modelItem;
    }

    private void walkDepthFirst(AST ast) {
        // walk (traverse the whole tree in a depth-first-manner)
        for (AST tmp = ast.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) { // walking from x---to--->z

            doFileLevelAction(tmp);
        }
    }

    private void walkPreOrderTraversal(AST ast) {
        // walk the current level from (x---to--->z)
        for (AST tmp = ast.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            preOrderStack.push(tmp);// when reading from the stack we get the
            // inverse order
            preOrderQueue.add(tmp);// queue gives us the original order of the
            // elements

            walkPreOrderTraversal(tmp);// walking down
        }
    }

    private void doFileLevelAction(AST node) { // TODO throws MoDiException {
        int type = node.getType();

        switch (type) { // switch over the interesting types, ignoring the rest.

        case GeneratedJavaTokenTypes.PACKAGE_DEF:// 0..1 package definition
            // can appear
            String namespace = getDottedIDENTString(node);
            modelItem.setNamespace(namespace);
            break;

        case GeneratedJavaTokenTypes.IMPORT:// 0..* imports can appear
            String importStatement = getDottedIDENTString(node);
            modelItem.addImport(importStatement);
            break;

        case GeneratedJavaTokenTypes.INTERFACE_DEF:// 1 interface definition
            // can appear
            modelItem.setType("interface");
            // TODO refactor this to enum like: type{interface, class}
            doClassLevelActions(node);
            break;

        case GeneratedJavaTokenTypes.CLASS_DEF:// 1 class definition can appear
            modelItem.setType("class");
            doClassLevelActions(node);
            break;

        default:
            // TODO throw new MoDiTransformerException("somethings wrong,
            // grammar? this should be java5");
            break;
        }
    }

    private void doClassLevelActions(AST node) {
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            int type = tmp.getType();
            switch (type) {
            case GeneratedJavaTokenTypes.MODIFIERS:
                List<String> modifiers = getLeafs(tmp);
                modelItem.setModifiers(modifiers);
                break;

            case GeneratedJavaTokenTypes.IDENT:
                String name = tmp.getText();
                modelItem.setName(name);
                break;

            case GeneratedJavaTokenTypes.EXTENDS_CLAUSE:// node always exists
                // (is leaf if no superclass is given)!
                doExtendsLevelActions(tmp);
                break;

            case GeneratedJavaTokenTypes.IMPLEMENTS_CLAUSE:
                // on to the interfaces
                doExtendsLevelActions(tmp);
                break;

            case GeneratedJavaTokenTypes.OBJBLOCK:
                doObjectLevelActions(tmp);
                break;

            default:
                // TODO throw new MoDiTransformerException("ooops!!");
                break;
            }
        }
    }

    private void doExtendsLevelActions(AST node) {
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            int type = tmp.getType();
            switch (type) { // switch over the interesting types, ignoring the
            // rest.

            case GeneratedJavaTokenTypes.IDENT:
                IModelItem superclass = new ModelItem();
                superclass.setName(tmp.getText());
                modelItem.addExtendee(superclass);
                break;

            default:
                break;
            }
        }
    }

    private void doObjectLevelActions(AST node) {
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            int type = tmp.getType();
            switch (type) {
            case GeneratedJavaTokenTypes.VARIABLE_DEF:
                doVariableLevelActions(tmp);
                break;

            case GeneratedJavaTokenTypes.METHOD_DEF:
                doOperationLevelAction(tmp);
                break;

            case GeneratedJavaTokenTypes.CLASS_DEF:
                // doClassLevelActions(tmp);//TODO review this!
                LOGGER.info("/!\\ inner class definitions not supported atm.");
                break;

            case GeneratedJavaTokenTypes.INTERFACE_DEF:
                // doClassLevelActions(tmp);//TODO review this!
                LOGGER.info("/!\\ inner class definitions not supported atm.");
                break;
            default:
                // TODO throw new MoDiTransformerException("ooops!!");
                break;
            }
        }

    }

    private void doVariableLevelActions(AST node) {
        memberVariable = new Variable();
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            int type = tmp.getType();
            switch (type) {
            case GeneratedJavaTokenTypes.MODIFIERS:
                memberVariable.setModifiers(getLeafs(tmp));
                break;

            case GeneratedJavaTokenTypes.TYPE:
                ModelItem variableType = new ModelItem();
                String variableTypeIdentifier = tmp.getFirstChild().getText();
                variableType.setName(variableTypeIdentifier);
                memberVariable.setType(variableType);
                break;

            case GeneratedJavaTokenTypes.IDENT:
                String identifier = modelItem.getIdentifier() + "."
                        + tmp.getText();
                memberVariable.setNamespace(modelItem.getIdentifier());
                memberVariable.setName(identifier);
                break;

            case GeneratedJavaTokenTypes.ASSIGN:
                // TODO do some assignments
                break;

            default:
                // TODO throw new MoDiTransformerException("ooops!!");
                break;
            }
        }
        modelItem.addMember(memberVariable);
    }

    private void doOperationLevelAction(AST node) {
        memberOperation = new Operation();
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            int type = tmp.getType();
            switch (type) {
            case GeneratedJavaTokenTypes.MODIFIERS:
                memberOperation.setModifiers(getLeafs(tmp));
                break;

            case GeneratedJavaTokenTypes.TYPE:
                ModelItem operationType = new ModelItem();
                String operationTypeIdentifier = tmp.getFirstChild().getText();
                operationType.setName(operationTypeIdentifier);
                memberOperation.setType(operationType);
                break;

            case GeneratedJavaTokenTypes.IDENT:
                memberOperation.setNamespace(modelItem.getIdentifier());
                memberOperation.setName(tmp.getText());
                break;

            case GeneratedJavaTokenTypes.PARAMETERS:
                doParameterLevelAction(tmp);
                break;

            default:
                // TODO throw new MoDiTransformerException("ooops!!");
                break;
            }
        }
        modelItem.addMember(memberOperation);
    }

    private void doParameterLevelAction(AST node) {
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            doParameterDefinitionLevelAction(tmp);
        }
    }

    private void doParameterDefinitionLevelAction(AST node) {
        parameter = new Parameter();
        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {

            int type = tmp.getType();
            switch (type) {

            case GeneratedJavaTokenTypes.MODIFIERS:
                // TODO do we need something here? foo(final int i)
                break;

            case GeneratedJavaTokenTypes.TYPE:
                ModelItem parameterType = new ModelItem();
                String parameterTypeIdentifier = tmp.getFirstChild().getText();
                // String parameterTypeIdentifer = getNodeTextForType(tmp,
                // GeneratedJavaTokenTypes.IDENT);
                parameterType.setName(parameterTypeIdentifier);
                parameter.setType(parameterType);
                break;

            case GeneratedJavaTokenTypes.IDENT:
                String identifier = tmp.getText();
                parameter.setNamespace(memberOperation.getIdentifier());
                parameter.setName(identifier);
                break;

            default:
                break;
            }
        }
        memberOperation.addParameter(parameter);
    }

    // _______generic___________________________________________________________
    private String getDottedIDENTString(AST node) {
        String result = "";
        preOrderStack = new Stack<AST>();
        preOrderQueue = new LinkedList<AST>();
        walkPreOrderTraversal(node);// fill the stack and the queue

        AST tmp;
        while (!preOrderQueue.isEmpty()) {
            tmp = preOrderQueue.remove();
            int type = tmp.getType();

            switch (type) { // switch over the interesting types, ignoring the
            // rest.

            case GeneratedJavaTokenTypes.IDENT:
                result += tmp.getText() + ".";
                break;
                
            case GeneratedJavaTokenTypes.STAR:
                result += tmp.getText() + ".";
                break;
                
            default:
                break;
            }
        }
        return result.substring(0, result.length() - 1);
    }

    private List<String> getLeafs(AST node) {
        List<String> result = new ArrayList<String>();
        preOrderStack = new Stack<AST>();
        preOrderQueue = new LinkedList<AST>();

        walkPreOrderTraversal(node);// fill the stack

        AST tmp;
        while (!preOrderStack.isEmpty()) {
            tmp = preOrderStack.pop();
            result.add(tmp.getText());
        }
        preOrderStack = null;

        return result;
    }

    /*private String getNodeTextForType(AST node, int tokenType) {
        String result = null;

        for (AST tmp = node.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) {
            if (tmp.getType() == tokenType) {
                return result = tmp.getText();
            }
        }

        return result;
    }*/
}
