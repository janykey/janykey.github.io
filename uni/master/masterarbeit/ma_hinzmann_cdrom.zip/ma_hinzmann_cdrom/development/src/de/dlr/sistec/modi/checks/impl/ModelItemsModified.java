/*
 * InterfacesModified.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $$Id: InterfacesModified.java 170 2007-03-21 09:29:45Z hinz_ja $$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

public class ModelItemsModified extends Check {

    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();
        List<IModelElement> amInterfaces = super.getAMModelElements();
        List<IModelElement> dmInterfaces = super.getDMModelElements();
        
        Map<IModelElement, IModelElement> modifiedInterfaces 
            = new HashMap<IModelElement, IModelElement>();

        for (IModelElement dmItem : dmInterfaces) {
            String dmIdentifier = ((IModelItem) dmItem).getNamespace() + "."
                    + ((IModelItem) dmItem).getIdentifier();

            for (IModelElement amItem : amInterfaces) {
                String amIdentifier = ((IModelItem) amItem).getNamespace()
                        + "." + ((IModelItem) amItem).getIdentifier();

                if ((amIdentifier.equals(dmIdentifier))
                        && !(amItem.equals(dmItem))) {
                    
                    modifiedInterfaces.put(amItem, dmItem);
                }
            }
        }

        for (IModelElement amItem : modifiedInterfaces.keySet()) {
            IDifference difference = new Difference();
            difference.setName(super.getName());
            difference.setSeverity(super.getSeverity());
            difference.setDescription("The " + ((IModelItem) amItem).getType()
                    + " \"" + amItem.getIdentifier()
                    + "\" has been modified.");
            difference.setLayer(IDifference.Layer.MODELITEM);
            difference.setStatus(IDifference.Status.MODIFIED);
            difference.setAMElement(amItem);
            difference.setDMElement(modifiedInterfaces.get(amItem));
            results.add(difference);
        }

        return results;
    }

}
