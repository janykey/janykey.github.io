/*
 * Config.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Config.java 373 2007-06-01 22:26:35Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import de.dlr.sistec.modi.exception.MoDiException;


public class Config {

    private static final Properties PROPERTIES =  new Properties();
   
    /** This is a utility class, so its constructor is private. */
    static {
        String configLocation = System.getProperty("MODICONFIG");
        if (configLocation == null) {
            System.out.println("MODICONFIG property has not been set.");
            System.exit(1);
        }
        try {
            
            PROPERTIES.load(new FileInputStream(configLocation));
            
        } catch (FileNotFoundException e) {
            String workingdir = System.getProperty("user.dir");
            System.out.println("The configuration file could not be found. "
                    + "Please let the MODICONFIG environment variable point to "
                    + "the configuration file. \n" 
                    + "The current value of MODICONFIG is: " + configLocation 
                    + "\nThe current working directory is: " + workingdir);
            System.exit(1);

        } catch (IOException e) {
        
            System.out.println("An IOException ocurred: " + e.getMessage());
            System.exit(1);
            
        }
    }
    
    private Config() {
    }

    public static String getStringProperty(String key) throws MoDiException {
        try {
        
            return  PROPERTIES.getProperty(key);
     
        } catch (NullPointerException e) {
            throw new MoDiException("The key (" + key + " was null!\n" 
                    + e.getMessage());
        }
    }
    
    /**
     * Return a List of numbered rule properties (e.g. MoDi.Rule.1.Name )
     * or NULL if the property could not be found.
     * @param i the number of the configured item like: MoDi.Rule.1.name
     * @return a list of properties or null if the property could not be found.
     */
    public static List<String> getRuleProperties(int i) {
        return getMultiProperties(i, "MoDi.Rule");
    }

    /**
     * Return a List of numbered mail properties (e.g. MoDi.Mail.1.Name )
     * or NULL if the property could not be found.
     * @param i the number of the configured item like: MoDi.Mail.1.name
     * @return a list of properties or null if the property could not be found.
     */
    public static List<String> getMailProperties(int i) {
        return getMultiProperties(i, "MoDi.Mail");
    }
    
    private static List<String> getMultiProperties(int i, String id) {
        List<String> result = new ArrayList<String>();
        
        String number = Integer.toString(i);
        
        Set propKeys = PROPERTIES.keySet();
        Iterator propIter = propKeys.iterator();
        
        while (propIter.hasNext()) {
            String tmp = (String)propIter.next(); 
            if (tmp.contains(id + "." + number + ".")) {
                result.add(tmp);
            }
        }
        if (result.isEmpty()) {
            return null;
        }
        return result;
    }
    
   
    
}
