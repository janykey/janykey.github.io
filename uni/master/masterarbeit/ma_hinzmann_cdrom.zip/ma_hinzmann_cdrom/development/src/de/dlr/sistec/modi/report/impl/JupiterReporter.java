/*
 * JupiterReporter.java
 *
 * <Beschreibung>
 *
 * Created: Mar 23, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.report.impl;

import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.IReporter;

/**
 * @author Jan Hinzmann
 *
 */
public class JupiterReporter implements IReporter {

    
    /**
     * this has to be instantiated through the ReporterFactory.
     */
    protected JupiterReporter() {
        
    }
    
    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.report.IReporter
     *  #report(de.dlr.sistec.modi.report.IReport)
     */
    public void report(IReport report) {
        
/*
<?xml version="1.0" encoding="UTF-8"?>
<Review id="modi_code_review_20070316">
  <ReviewIssue id="EZCG1F6J">
    <ReviewIssueMeta>
      <CreationDate format="yyyy-MM-dd :: HH:mm:ss:SSS z">
          2007-03-16 :: 10:43:33:403 CET
      </CreationDate>
      <LastModificationDate format="yyyy-MM-dd :: HH:mm:ss:SSS z">
          2007-03-16 :: 10:43:54:786 CET
      </LastModificationDate>
    </ReviewIssueMeta>
    <ReviewerId>tmetsch</ReviewerId>
    <AssignedTo>tmetsch</AssignedTo>
    <File line="15">src/de/dlr/sistec/modi/MoDi.java</File>
    <Type>item.type.label.codingStandards</Type>
    <Severity>item.severity.label.normal</Severity>
    <Summary>unused import</Summary>
    <Description>logging</Description>
    <Annotation />
    <Revision />
    <Resolution>item.label.unset</Resolution>
    <Status>item.status.label.open</Status>
  </ReviewIssue>
</Review>

*/

    }

}
