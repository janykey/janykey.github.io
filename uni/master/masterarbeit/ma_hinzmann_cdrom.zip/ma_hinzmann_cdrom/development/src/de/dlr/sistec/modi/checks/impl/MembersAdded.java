/*
 * MembersAdded.java
 *
 * <Beschreibung>
 *
 * Created: Feb 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $$Id: MembersAdded.java 187 2007-03-23 14:34:25Z hinz_ja $$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

/**
 * @author Jan Hinzmann
 * 
 */
public class MembersAdded extends Check {

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.ICheck#check()
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();

        Map<IModelElement, IModelElement> modifiedInterfaces = 
            getModifiedInterfaces(currentDifferences);

        for (IModelElement amElement : modifiedInterfaces.keySet()) {

            List<IMember> amMembers = ((IModelItem) amElement).getMembers();
            List<IMember> dmMembers = ((IModelItem) modifiedInterfaces
                    .get(amElement)).getMembers();

            // compute the added members
            List<IMember> addedMembers = new ArrayList<IMember>();
            addedMembers.addAll(dmMembers);

            for (IMember member : amMembers) {
                String amIdentifier = member.getIdentifier();

                for (IMember addedMember : dmMembers) {
                    String dmIdentifier = addedMember.getIdentifier();

                    if (amIdentifier.equals(dmIdentifier)) {
                        addedMembers.remove(addedMember);
                    }
                }
            }

            // now we have the added members for this interface

            for (IMember member : addedMembers) {
                IDifference difference = new Difference();
                difference.setName(super.getName());
                difference.setSeverity(super.getSeverity());
                difference.setDescription("The member \"" 
                        + member.getIdentifier() 
                        + "\" has been added to \""
                        + modifiedInterfaces.get(amElement).getIdentifier() 
                        + "\".");
                difference.setLayer(IDifference.Layer.MEMBER);
                difference.setStatus(IDifference.Status.ADDED);
                difference.setParentElement(modifiedInterfaces.get(amElement));
                difference.setDMElement((IModelElement) member);
                results.add(difference);
            }

        }
        return results;
    }

}
