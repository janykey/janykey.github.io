/*
 * MetaRepresentation.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: MetaRepresentation.java 215 2007-03-28 17:01:53Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import java.util.List;

import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.IParameter;


public class MetaRepresentation implements IMetaRepresentation {

    private static MetaRepresentation instance = null;

    private IModel amModel;

    private IModel dmModel;

    private MetaRepresentation() {
        amModel = new Model();
        amModel.setType(Model.Type.AM);

        dmModel = new Model();
        dmModel.setType(Model.Type.DM);
    }

    /**
     * the metarepresentation is a singleton in order to let the level1 checks
     * find the lists of interfaces.
     * @return
     */
    public static IMetaRepresentation getInstance() {
        if (instance == null) {
            instance = new MetaRepresentation();
        }
        return instance;
    }

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#getAmModel()
     */
    public IModel getAmModel() {
        return amModel;
    }

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#setAmModel(de.dlr
     *          .sistec.modi.metamodel.Model)
     */
    public void setAmModel(final IModel newArchitectsModel) {
        this.amModel = newArchitectsModel;
    }

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#getDmModel()
     */
    public IModel getDmModel() {
        return dmModel;
    }

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#setDmModel(de.dlr
     *          .sistec.modi.metamodel.Model)
     */
    public void setDmModel(final IModel newDevelopersModel) {
        this.dmModel = newDevelopersModel;
    }

    // ___handling meta data____________________________________________________

    // public void addModel(Model.Type type, HashMap modelData) ;
    // public void addModelItem(Model.Type type, HashMap modelItemData);
    // public void addConstant(ModelItem modelItem);
    // public void addOperation(ModelItem modelItem);
    // public void addParameter(Operation operation);
    //
    // //retrieve

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#getModelItems(de
     *          .dlr.sistec.modi.metamodel.Model.PersistenceType)
     */
    public List<IModelItem> getModelItems(final Model.Type type) {

        List<IModelItem> result = null;

        if (type == Model.Type.AM) {
            result = amModel.getItems();
        }
        if (type == Model.Type.DM) {
            result = dmModel.getItems();
        }

        return result;
    }

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#getMembers(de.dlr
     *          .sistec.modi.metamodel.ModelItem)
     */
    public List<IMember> getMembers(final IModelItem modelItem) {
        List<IMember> result = modelItem.getMembers();
        return result;
    }

    /**
     * {@inheritDoc}
     *
     * @see de.dlr.sistec.modi.metamodel.IMetaRepresentation#getParameters(de
     *          .dlr.sistec.modi.metamodel.Operation)
     */
    public List<IParameter> getParameters(final IOperation operation) {
        List<IParameter> result = operation.getParameters();
        return result;
    }

    /**
     * The toString method for MetaRepresentation.
     * @return a String representation of this class.
     */
    public String toString() {
        return "AM Model: " + amModel + "\n\n----------------------------\n\n"
                + "DM Model: " + dmModel;
    }
}
