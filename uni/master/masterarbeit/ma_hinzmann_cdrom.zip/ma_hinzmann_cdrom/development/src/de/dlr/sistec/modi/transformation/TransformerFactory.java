/*
 * TransformerFactory.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: TransformerFactory.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import de.dlr.sistec.modi.MoDi;
import de.dlr.sistec.modi.transformation.impl.java.JavaTransformer;


public class TransformerFactory {

    public static ITransformer create(MoDi.Language language) {

        switch (language) {
        case JAVA:
            return new JavaTransformer();
            
        default:
            return create(MoDi.Language.JAVA);
        }
    }
}
