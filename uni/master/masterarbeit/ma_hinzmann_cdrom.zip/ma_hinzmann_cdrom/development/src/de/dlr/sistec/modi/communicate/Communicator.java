/*
 * Communicator.java
 *
 * <Beschreibung>
 *
 * Created: May 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.communicate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;

import de.dlr.sistec.modi.Config;
import de.dlr.sistec.modi.MoDi.ReportStyle;
import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.IDifference.Severity;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.report.IReport;
import de.dlr.sistec.modi.report.IReporter;
import de.dlr.sistec.modi.report.impl.Report;
import de.dlr.sistec.modi.report.impl.ReporterFactory;

/**
 * @author Jan Hinzmann
 * 
 */
public class Communicator {

    private String mailhost;

    private String fromAddress;

    private String username;

    private String password;

    private List<Role> roles;

    /**
     * 
     */
    public Communicator() throws MoDiException {
        roles = new ArrayList<Role>();
        setUpRolesFromConfig();
        fromAddress = Config.getStringProperty("MoDi.Mail.From");
        mailhost = Config.getStringProperty("MoDi.Mail.Host");
        username = Config.getStringProperty("MoDi.Mail.User");
        password = Config.getStringProperty("MoDi.Mail.Pass");
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void addRole(Role role) {
        roles.add(role);
    }

    public void removeRole(Role role) {
        roles.remove(role);
    }

    public void setUpRolesFromConfig() throws MoDiException {
        List<String> mailConfig;
        for (int i = 1; (mailConfig = Config.getMailProperties(i)) != null; i++)
        {
            setUpRole(mailConfig);
        }
    }

    private void setUpRole(List<String> roleConfig) throws MoDiException {

        String name = null;
        String email = null;

        for (String string : roleConfig) {
            if (string.endsWith("Name")) {
                name = Config.getStringProperty(string);
            }
            if (string.endsWith("EMail")) {
                email = Config.getStringProperty(string);
            }
        }

        roles.add(new Role(name, email));
    }

    public void communicate(IReport report) throws EmailException,
            MoDiException {

        // Create the attachment
        EmailAttachment attachment = new EmailAttachment();
        attachment
                .setPath(Config.getStringProperty("MoDi.HTMLReportFile.Path"));
        attachment.setDisposition(EmailAttachment.ATTACHMENT);
        attachment.setDescription("MoDiHTMLReport");
        attachment.setName("modireport.html");

        // Create the email message
        MultiPartEmail email = new MultiPartEmail();
        email.setHostName(mailhost);
        email.setAuthentication(username, password);
        email.setFrom(fromAddress, "MoDi");

        for (Role role : roles) {
            email.addTo(role.getEmail(), role.getName());
        }

        // subject
        String projectName = Config.getStringProperty("MoDi.Meta.Project.Name");

        List<IDifference> diffs = report.getDifferences();
        int diffsHigh = 0;
        int diffsMedium = 0;
        int diffsLow = 0;
        for (IDifference diff : diffs) {
            if (diff.getSeverity() == IDifference.Severity.HIGH) {
                diffsHigh++;
            }
            if (diff.getSeverity() == IDifference.Severity.MEDIUM) {
                diffsMedium++;
            }
            if (diff.getSeverity() == IDifference.Severity.LOW) {
                diffsLow++;
            }
        }
        int diffsAll = diffsHigh + diffsMedium + diffsLow;

        String subjectString = "[MoDi] " + projectName + ": " + diffsAll
                + " Differences" + " (H:" + diffsHigh + ", M:" + diffsMedium
                + ", L:" + diffsLow + ")";

        email.setSubject(subjectString);

        email.setMsg(" ");
        email.attach(attachment);
        email.send();

    }

    public IReport setUpTestReport() {

        IDifference diffHigh = new Difference();
        diffHigh.setSeverity(Severity.HIGH);
        diffHigh.setDescription("The interface IFoo has been brutally deleted "
                + "from the Architecture!!");

        IDifference diffMedium = new Difference();
        diffMedium.setSeverity(Severity.MEDIUM);
        diffMedium.setDescription("The interface IBar has been added to"
                + " the Architecture. Thx! :o)");

        IDifference diffLow = new Difference();
        diffLow.setSeverity(Severity.LOW);
        diffLow.setDescription("The class FooImpl has a new private method "
                + "generateStringFromODS");

        IReport report = new Report();
        report.setArchitect("Jan Hinzmann");
        report.setDate(new Date(System.currentTimeMillis()));
        report.add(diffHigh);
        report.add(diffMedium);
        report.add(diffLow);

        IReporter htmlReporter = ReporterFactory.create(ReportStyle.HTML);
        htmlReporter.report(report);// the report is now stored on the harddrive

        return report;
    }

    public static void main(String[] args) throws Exception {
        System.setProperty("MODICONFIG",
                "/home/jan/workspace/MoDi/conf/config.properties");
        Communicator commi = new Communicator();

        try {
            commi.communicate(commi.setUpTestReport());
            System.out.println("done sending.");

        } catch (EmailException e) {
            System.out.println("Somethings wrong with email communication:\n"
                    + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } catch (MoDiException e) {
            System.out.println("Somethings wrong within the system:\n"
                    + e.getMessage());
            System.exit(1);
        }
    }
}
