/*
 * Parameter.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Parameter.java 307 2007-05-22 11:29:44Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IParameter;

public class Parameter implements IModelElement, IParameter {

    private String namespace;

    private String name;

    private IModelItem type;

    public Parameter() {
        namespace = "";
        name = "";
        type = new ModelItem();
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IParameter#setIdentifier(java.lang.String)
     */
    public void setNamespace(final String newNamespace) {
        this.namespace = newNamespace;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IParameter#getIdentifier()
     */
    public String getNamespace() {
        return namespace;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IParameter#setIdentifier(java.lang.String)
     */
    public void setName(final String newName) {
        this.name = newName;
    }

    /**
     * Returns the identifier as dotted concatenation of the namespace and the
     * name of this ModelElement.
     */
    public String getIdentifier() {
        return namespace + "." + name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IParameter#getIdentifier()
     */
    public String getName() {
        return name;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl .IParameter#getType()
     */
    public IModelItem getType() {
        return type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl
     *      .IParameter#setType(de.dlr.sistec.modi.metarepresentation.impl.ModelItem)
     */
    public void setType(final IModelItem newType) {
        this.type = newType;
    }

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl.IParameter#equals(java
     *      .lang.Object)
     */
    public boolean equals(Object obj) {
        boolean result = false;

        if (!(obj instanceof Parameter)) {
            return false;
        }

        Parameter other = (Parameter) obj;

        boolean identifierEqual = this.getIdentifier().equals(
                other.getIdentifier());
        
        boolean typeEqual = this.type.equals(other.getType());

        result = (identifierEqual && typeEqual);

        return result;
    }
    
    public int hashCode() {
        int result = 7;
        result = 31 * result + (null == namespace ? 0 : namespace.hashCode());
        result = 31 * result + (null == name ? 0 : name.hashCode());
        result = 31 * result + (null == type ? 0 : type.hashCode());
        return result;
    }


    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.metarepresentation.impl.IParameter#toString()
     */
    public String toString() {
        return type.getIdentifier() + " " + this.getIdentifier();
    }

   
}
