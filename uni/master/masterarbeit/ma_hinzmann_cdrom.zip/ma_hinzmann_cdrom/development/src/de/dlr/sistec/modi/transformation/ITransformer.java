/*
 * ITransformer.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: ITransformer.java 296 2007-05-22 11:10:09Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.transformation;

import java.io.File;
import java.util.List;

import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.metarepresentation.IModel;

public interface ITransformer {

    /*
     * First find the files for the AM and the DM and then parse the files
     * an get ASTs of every file Then connect these ASTs to a ModelTree (for
     * each model) Finally store the ModelTrees in the MetaRepresentation.
     */

    IModel transform(List<File> modelFiles) throws MoDiException;

}
