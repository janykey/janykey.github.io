/*
 * IModel.java
 *
 * <Beschreibung>
 *
 * Created: Mar 26, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import java.util.List;

import de.dlr.sistec.modi.metarepresentation.impl.Model;

/**
 * @author Jan Hinzmann
 *
 */
public interface IModel {

    String getAuthor();

    void setAuthor(final String newAuthor);

    List<IModelItem> getItems();

    void setItems(final List<IModelItem> newItems);

    void addModelItem(final IModelItem newItem);

    String getRevision();

    void setRevision(final String newRevision);

    Model.Type getType();

    void setType(final Model.Type newType);

    /**
     * The equals method for Model. 
     */
    boolean equals(Object obj);

    String toString();

}
