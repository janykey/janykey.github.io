/*
 * ClassesAdded.java
 *
 * <Beschreibung>
 *
 * Created: Jun 2, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;

/**
 * @author Jan Hinzmann
 *
 */
public class ClassesAdded extends ModelItemsAdded {

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.checks.ICheck#check(java.util.List)
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        
        super.reduceProblemSpaceToClasses();
        return super.check(currentDifferences);
    }

}
