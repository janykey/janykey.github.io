/*
 * AddedPublicMethodsInImplementingClasses.java
 *
 * <Beschreibung>
 *
 * Created: Apr 28, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;

/**
 * @author Jan Hinzmann
 * 
 */
public class AddedPublicMethodsInImplementingClasses extends Check {

    /**
     * @see de.dlr.sistec.modi.checks.ICheck#check(java.util.List) {@inheritDoc}
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> result = new ArrayList<IDifference>();

        List<IModelItem> amInterfaces = getInterfaces(Model.Type.AM);

        for (IModelItem anInterface : amInterfaces) {

            List<IModelItem> implementingClasses 
            = getImplementingClasses(anInterface);
            
            for (IModelItem implementingClass : implementingClasses) {

                List<IMember> addedMethods = checkPublicMethods(
                        getPublicOperations(anInterface),
                        getPublicOperations(implementingClass));

                if (!addedMethods.isEmpty()) {
                    IDifference difference = new Difference();
                    difference.setDescription("The class " 
                            + implementingClass.getIdentifier()
                            + " has a public method that is not specified in"
                            + " its interface " + anInterface.getIdentifier());
                    difference.setDMElement((IModelElement)implementingClass);
                    difference.setSeverity(super.getSeverity());
                    difference.setStatus(IDifference.Status.MODIFIED);
                    
                    result.add(difference);
                }
            }
        }

        return result;
    }

    private List<IModelItem> getImplementingClasses(IModelItem anInterface) {
        List<IModelItem> result = new ArrayList<IModelItem>();

        List<IModelItem> dmModelItems = MetaRepresentation.getInstance()
                .getModelItems(Model.Type.DM);

        String interfaceID = anInterface.getIdentifier();
        
        for (IModelItem item : dmModelItems) {
            if (item.getType().equals("class")) {
                List<IModelItem> itemsInterfaces = item.getExtendees();
                for (IModelItem item2 : itemsInterfaces) {
                    if (interfaceID.equals(item2.getIdentifier())) {
                        result.add(item);                        
                    }
                }
            }
        }

        return result;
    }

    /**
     * Finds the methods that are added in the classes.
     * @param publicInterfaceMethods
     * @param publicClassMethods
     * @return
     */
    private List<IMember> checkPublicMethods(
            List<IMember> publicInterfaceMethods,
            List<IMember> publicClassMethods) {
        
        List<IMember> result = new ArrayList<IMember>();
        result.addAll(publicClassMethods);
        
        //removing all members that are also in the interface. Therefore only
        //members are left that have been added.
        for (IMember interfaceMethod : publicInterfaceMethods) {
            String interfaceMethodID = interfaceMethod.getName();
            
            for (IMember classMethod : publicClassMethods) {
                String classMemberID = classMethod.getName();
                
                if (interfaceMethodID.equals(classMemberID)) {
                    result.remove(classMethod);
                }
            }
        }
        return result;
    }
}
