/*
 * FileFinderFactory.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: FileFinderFactory.java 260 2007-04-23 11:04:24Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation;

import de.dlr.sistec.modi.MoDi;
import de.dlr.sistec.modi.transformation.impl.FilesystemFinder;

/**
 * @author Jan Hinzmann
 *
 */
public class FileFinderFactory {

    
    public static IFileFinder create(MoDi.ImportHandler importHandler) {

        switch (importHandler) {
        case FILESYSTEM:
            return new FilesystemFinder();
            
        default:
            return create(MoDi.ImportHandler.FILESYSTEM);
        }
        
    }
}
