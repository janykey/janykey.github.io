/*
 * FilesystemFinder.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: FilesystemFinder.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.transformation.impl;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import de.dlr.sistec.modi.exception.MoDiException;
import de.dlr.sistec.modi.transformation.IFileFinder;


public class FilesystemFinder implements IFileFinder {

    private FileFilter filter;

    private FilenameFilter filenameFilter;

    private File dir;

    private List<File> dirs;

    public FilesystemFinder() {
        // a filter
        filter = new FileFilter() {
            public boolean accept(File file) {
                return file.isDirectory();
            }
        };

        // we store the dirs found in 'dirs'.
        this.dirs = new ArrayList<File>();
    }

    public List<File> findFiles(File rootDir, String pattern)
            throws MoDiException {
        if (rootDir == null || pattern == null) {
            throw new MoDiException("Neither \"rootDir\" nor \"pattern\" are"
                    + "allowed to be null!");
        }
        List<File> results = new ArrayList<File>();
        List<File> workdirs = new ArrayList<File>();
        filenameFilter = new FileFinderFilter(pattern);

        // we can work on a single file too
        if (rootDir.isFile() && rootDir.getAbsolutePath().endsWith(pattern)) {
            results.add(rootDir);
            return results;
        }
        // we only work on directories
        if (rootDir.isDirectory()) {
            this.dir = rootDir;
        } else {
            throw new MoDiException("Please specify a root directory. I "
                    + "found: \"" + rootDir + "\" not to " + "be a directory.");
        }

        workdirs.add(dir);// setup for workdir

        // find more subdirs until workdirs is empty
        while (!workdirs.isEmpty()) {
            List<File> addList = new ArrayList<File>();
            List<File> removeList = new ArrayList<File>();

            for (Iterator workDirsIter = workdirs.iterator(); workDirsIter
                    .hasNext();) {
                File tmpDir = (File) workDirsIter.next();

                // ---- do something with the tmpDir ------------------
                File[] tmpFiles = tmpDir.listFiles(filenameFilter);// all files
                // matching
                // the
                // pattern
                for (File file : tmpFiles) {
                    if (!file.isDirectory()) { // TODO hotfix!!!24.04.2007
                        results.add(file);
                    }
                }
                // ---- done with the tmpDir ---------------------------

                removeList.add(tmpDir);
                addList.addAll(getSubdirs(tmpDir));
            }
            workdirs.removeAll(removeList);
            workdirs.addAll(addList);
            dirs.addAll(addList);
        }

        return results;
    }

    private List<File> getSubdirs(final File parentDir) {
        List<File> result = new ArrayList<File>();

        File[] tmp = parentDir.listFiles(filter);
        if (tmp == null) {
            return null;
        }

        for (File file : tmp) {
            result.add(file);
        }
        return result;
    }
}
