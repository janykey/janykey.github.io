/*
 * ASTtoXMLTransformer.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: ASTtoXMLTransformer.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation.impl.java;

import antlr.collections.AST;


public class ASTtoXMLTransformer {

    private StringBuffer result;

    public ASTtoXMLTransformer() {
        result = new StringBuffer();
    }

    public StringBuffer walk(AST ast) {

        append("<modelitem>\n  <filename>" + ast.getText() + "</filename>\n");
        walkDepthFirst(ast, 1);// walk the tree and fill the modelItem
        append("</modelitem>");

        return result;
    }

    private void walkDepthFirst(AST ast, int depth) {
        // walk (traverse the whole tree in a depth-first-manner)
        for (AST tmp = ast.getFirstChild(); tmp != null; tmp = tmp
                .getNextSibling()) { // walking from x---to--->z

            int newDepth = depth + 1;

            xmalizeOpenTag(tmp, depth);
            walkDepthFirst(tmp, newDepth);// walking down
            xmalizeCloseTag(tmp, depth);
        }
    }

    private void xmalizeOpenTag(AST node, int depth) {

        String type = TokenTypeHelper.getStringForType(node.getType());
        type = type.toLowerCase();

        if (node.getNumberOfChildren() == 0) { // no children
            append(getIndent(depth) + "<" + type + ">");
        } else {
            append(getIndent(depth) + "<" + type + ">\n");
        }
    }

    private void xmalizeCloseTag(AST node, int depth) {
        String type = TokenTypeHelper.getStringForType(node.getType())
                .toLowerCase();

        if (node.getNumberOfChildren() == 0) { // no children
            append(node.getText() + "</" + type + ">\n");
        } else {
            append(getIndent(depth) + "</" + type + ">\n");
        }
    }

    private String getIndent(int depth) {
        String indent = "";
        while (depth > 0) {
            indent += "  ";
            depth--;
        }
        return indent;
    }

    private void append(String toappend) {
        result.append(toappend);
    }

}
