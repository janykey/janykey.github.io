/*
 * Model.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Model.java 307 2007-05-22 11:29:44Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.metarepresentation.IModel;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

public class Model implements IModel, IModelElement {

    /**
     * A model can be of the architectural type, developer type or the type has
     * not been specified yet.
     * 
     * @author Jan Hinzmann
     */
    public static enum Type {
        AM, DM, UNDEFINED
    };

    private Type type;

    private String author;

    private String revision;

    private List<IModelItem> items;

    public Model() {
        author = "";
        revision = "";
        items = new ArrayList<IModelItem>();
        type = Type.UNDEFINED;
    }

    public String getIdentifier() {
        String tmpType = null;
        if (this.getType() == Type.AM) {
            tmpType = "AM";
        } else if (this.getType() == Type.DM) {
            tmpType = "DM";
        } else {
            tmpType = "No type set.";
        }
        return tmpType;
    }
    
    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IModel#getAuthor()
     */
    public String getAuthor() {
        return author;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IModel#setAuthor(java.lang.String)
     */
    public void setAuthor(final String newAuthor) {
        this.author = newAuthor;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IModel#getItems()
     */
    public List<IModelItem> getItems() {
        return items;
    }
    

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IModel#setItems(java.util.List)
     */
    public void setItems(final List<IModelItem> newItems) {
        this.items = newItems;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IModel#addModelItem(de.dlr.sistec.modi.metarepresentation.IModelItem)
     */
    public void addModelItem(final IModelItem newItem) {
        items.add(newItem);
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IModel#getRevision()
     */
    public String getRevision() {
        return revision;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IModel#setRevision(java.lang.String)
     */
    public void setRevision(final String newRevision) {
        this.revision = newRevision;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IModel#getType()
     */
    public Type getType() {
        return type;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IModel#setType(de.dlr.sistec.modi.metarepresentation.impl.Model.Type)
     */
    public void setType(final Type newType) {
        this.type = newType;
    }

    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl
     * .IModel#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {

        if (!(obj instanceof Model)) {
            return false;
        }
        IModel other = (IModel) obj;

        boolean result = false;

        boolean typeEquals = this.type.equals(other.getType());
        boolean authorEquals = this.author.equals(other.getAuthor());
        boolean revisionEquals = this.revision.equals(other.getRevision());

        boolean itemsSizeEquals = (this.getItems().size() == other.getItems()
                .size());
        boolean itemsContainsEquals = this.getItems().containsAll(
                other.getItems());
        boolean itemsEquals = (itemsSizeEquals && itemsContainsEquals);

        result = (typeEquals && authorEquals && revisionEquals && itemsEquals);

        return result;
    }
    
    public int hashCode() {
        int result = 7;
        result = 31 * result + (null == type ? 0 : type.hashCode());
        result = 31 * result + (null == author ? 0 : author.hashCode());
        result = 31 * result + (null == revision ? 0 : revision.hashCode());
        result = 31 * result + (null == items ? 0 : items.hashCode());
        return result;
    }

    
    /* (non-Javadoc)
     * @see de.dlr.sistec.modi.metarepresentation.impl.IModel#toString()
     */
    public String toString() {
        String tmpType = null;
        if (this.getType() == Type.AM) {
            tmpType = "AM";
        } else if (this.getType() == Type.DM) {
            tmpType = "DM";
        } else {
            tmpType = "No type set.";
        }
        return "Model\n" + "  Type    : " + tmpType + "\n" + "  Author  : "
                + author + "\n" + "  Revision: " + revision + "\n"
                + "  Items   : " + items;
    }

}
