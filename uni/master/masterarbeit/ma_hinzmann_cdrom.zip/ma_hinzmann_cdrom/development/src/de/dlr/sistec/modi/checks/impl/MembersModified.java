/*
 * MembersModified.java
 *
 * <Beschreibung>
 *
 * Created: Mar 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

/**
 * @author Jan Hinzmann
 * 
 */
public class MembersModified extends Check {

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.ICheck#check()
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();

        // setup
        Map<IModelElement, IModelElement> modifiedInterfaces 
            = getModifiedInterfaces(currentDifferences);
        
        Map<IModelElement, IModelElement> modifiedMembers 
            = new HashMap<IModelElement, IModelElement>();

        // going through the modified interfaces, checking for members modified
        for (IModelElement amElement : modifiedInterfaces.keySet()) {

            List<IMember> amMembers = ((IModelItem) amElement).getMembers();
            List<IMember> dmMembers = ((IModelItem) modifiedInterfaces
                    .get(amElement)).getMembers();

            // checking for modified members
            for (IMember amMember : amMembers) {
                String amIdentifier = amMember.getIdentifier();

                for (IMember dmMember : dmMembers) {
                    String dmIdentifier = dmMember.getIdentifier();

                    if (amIdentifier.equals(dmIdentifier)
                            && !(amMember.equals(dmMember))) {

                        modifiedMembers.put((IModelElement) amMember,
                                (IModelElement) dmMember);

                    }
                }
            }
            //now we have all modified members found
            
            for (IModelElement member : modifiedMembers.keySet()) {
                IDifference difference = new Difference();
                difference.setName(super.getName());
                difference.setSeverity(super.getSeverity());
                difference.setDescription("The member \"" 
                        + member.getIdentifier() 
                        + "\" in the interface \"" 
                        + modifiedInterfaces.get(amElement).getIdentifier() 
                        + "\" has been modified.");
                difference.setLayer(IDifference.Layer.MEMBER);
                difference.setStatus(IDifference.Status.MODIFIED);
                difference.setAMElement(member);
                difference.setDMElement(modifiedMembers.get(member));
                difference.setParentElement(modifiedInterfaces.get(amElement));
                results.add(difference);
            }

        }

        return results;
    }

   
}
