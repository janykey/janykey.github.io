/*
 * ReporterFactory.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: ReporterFactory.java 147 2007-03-17 20:49:01Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.report.impl;

import de.dlr.sistec.modi.MoDi;
import de.dlr.sistec.modi.report.IReporter;

public class ReporterFactory {

    public static IReporter create(MoDi.ReportStyle style) {

        switch (style) {

        case CONSOLE:
            return new TerminalReporter();

        case XML:
            return new XMLReporter();

        case HTML:
            return new HTMLReporter();
            
        default:
            return new TerminalReporter();
        }

    }
}
