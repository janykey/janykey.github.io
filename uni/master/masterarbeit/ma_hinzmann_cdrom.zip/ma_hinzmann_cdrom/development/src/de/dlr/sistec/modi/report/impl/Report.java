/*
 * Report.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: Report.java 187 2007-03-23 14:34:25Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.report.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.report.IReport;


public class Report implements IReport {

    private List<IDifference> differences;
    private Date date;
    private String projectName;
    private String architect;
    private String developer;
    private String architectsModelVersion;
    private String developersModelVersion;
    

    public Report() {
        differences = new ArrayList<IDifference>();
        date = new Date();
        projectName = "";
        architect = "";
        developer = "";
        architectsModelVersion = "";
        developersModelVersion = "";
    }

    public void add(IDifference item) {
        differences.add(item);
    }

    public void addAll(List<IDifference> moreDifferences) {
        this.differences.addAll(moreDifferences);
    }

    /**
     * @return the differences
     */
    public List<IDifference> getDifferences() {
        return differences;
    }

    /**
     * @param newDifferences the differences to set
     */
    public void setDifferences(List<IDifference> newDifferences) {
        this.differences = newDifferences;
    }
    
 
    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(Date newDate) {
        this.date = newDate;
    }

    /**
     * @return the projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param newProjectName the projectName to set
     */
    public void setProjectName(final String newProjectName) {
        this.projectName = newProjectName;
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#getArchitect()
     */
    public String getArchitect() {
        return architect;
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#getArchitectsModelVersion()
     */
    public String getArchitectsModelVersion() {
        return architectsModelVersion;
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#getDeveloper()
     */
    public String getDeveloper() {
        return developer;
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#getDevelopersModelVersion()
     */
    public String getDevelopersModelVersion() {
        return developersModelVersion;
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#setArchitect(java.lang.String)
     */
    public void setArchitect(String name) {
        this.architect = name;
        
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#setArchitectsModelVersion(java
     *  .lang.String)
     */
    public void setArchitectsModelVersion(String version) {
        this.architectsModelVersion = version;
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#setDeveloper(java.lang.String)
     */
    public void setDeveloper(String name) {
        this.developer = name;        
    }

    /**
     * @see de.dlr.sistec.modi.report.IReport#setDevelopersModelVersion(java
     *  .lang.String)
     */
    public void setDevelopersModelVersion(String version) {
        this.developersModelVersion = version;
    }

}
