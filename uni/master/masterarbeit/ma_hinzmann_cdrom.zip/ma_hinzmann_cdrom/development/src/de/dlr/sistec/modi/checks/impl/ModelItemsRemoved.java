/*
 * InterfacesRemoved.java
 *
 * <Beschreibung>
 *
 * Created: Feb 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: InterfacesRemoved.java 187 2007-03-23 14:34:25Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;


public class ModelItemsRemoved extends Check {

    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();
        List<IModelElement> amModelItems = super.getAMModelElements();
        List<IModelElement> dmModelItems = super.getDMModelElements();
        
        List<IModelElement> removedModelItems = new ArrayList<IModelElement>();
        removedModelItems.addAll(amModelItems);

        for (IModelElement amItem : amModelItems) {
            String amIdentifier = ((IModelItem) amItem).getNamespace() + "."
                + ((IModelItem) amItem).getIdentifier();

            for (IModelElement dmItem : dmModelItems) {
                String dmIdentifier = ((IModelItem) dmItem).getNamespace() + "."
                    + ((IModelItem) dmItem).getIdentifier();

                //removing all model items found leads us to a rest of 
                //model items not be found - so they have been removed.
                if (amIdentifier.equals(dmIdentifier)) {
                    removedModelItems.remove(amItem);
                }
            }
        }
        
        for (IModelElement item : removedModelItems) {
            IDifference difference = new Difference();
            difference.setName(super.getName());
            difference.setSeverity(super.getSeverity());
            difference.setDescription("The " + ((IModelItem) item).getType()
                    + " \"" + item.getIdentifier()
                    + "\" has been removed from the model.");
            difference.setLayer(IDifference.Layer.MODELITEM);
            difference.setStatus(IDifference.Status.REMOVED);
            difference.setAMElement(item);
            results.add(difference);
        }
        
        return results;
    }

}
