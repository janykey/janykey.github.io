/*
 * IMember.java
 *
 * <Beschreibung>
 *
 * Created: Mar 26, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import java.util.List;


/**
 * @author Jan Hinzmann
 *
 */
public interface IMember {

    List<String> getModifiers();

    void setModifiers(final List<String> newModifiers);

    void addModifier(final String newModifier);

    IModelItem getType();

    void setType(final IModelItem newReturnType);


    void setName(String newName);
    String getName();

    void setNamespace(String newNamespace);
    String getNamespace();
    
    String getIdentifier();

    boolean equals(Object other);

}
