/*
 * IMetaRepresentation.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: IMetaRepresentation.java 214 2007-03-28 17:00:56Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation;

import java.util.List;

import de.dlr.sistec.modi.metarepresentation.impl.Model;

/**
 * @author Jan Hinzmann
 */
public interface IMetaRepresentation {

    IModel getAmModel();

    void setAmModel(IModel amModel);

    IModel getDmModel();

    void setDmModel(IModel dmModel);

    // public void addModel(Model.Type type, HashMap modelData) ;
    // public void addModelItem(Model.Type type, HashMap modelItemData);
    // public void addConstant(ModelItem modelItem);
    // public void addOperation(ModelItem modelItem);
    // public void addParameter(Operation operation);
    //
    // //retrieve
    List<IModelItem> getModelItems(Model.Type type);

    List<IMember> getMembers(IModelItem modelItem);

    List<IParameter> getParameters(IOperation operation);

}
