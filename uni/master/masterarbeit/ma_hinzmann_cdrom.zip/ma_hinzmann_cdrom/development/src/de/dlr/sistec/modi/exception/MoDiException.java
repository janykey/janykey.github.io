/*
 * MoDiException.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: MoDiException.java 147 2007-03-17 20:49:01Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.exception;

public class MoDiException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * @override
     */
    public MoDiException() {
        super();
    }

    /**
     * @override
     */
    public MoDiException(String message) {
        super(message);
    }

    /**
     * @override
     */
    public MoDiException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @override
     */
    public MoDiException(Throwable cause) {
        super(cause);
    }

}
