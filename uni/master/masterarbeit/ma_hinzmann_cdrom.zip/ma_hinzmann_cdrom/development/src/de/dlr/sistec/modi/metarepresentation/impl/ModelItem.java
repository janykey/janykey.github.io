/*
 * ModelItem.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: ModelItem.java 335 2007-05-24 13:42:14Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.metarepresentation.impl;

import java.util.ArrayList;
import java.util.List;

import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;

public class ModelItem implements IModelItem, IModelElement {

    private String namespace;

    private List<String> imports;

    private String name;

    private String type;// interface or class

    private List<String> modifiers;

    private List<IModelItem> extendees;

    private List<IMember> members; // Member = Constant / Operation

    public ModelItem() {
        namespace = "";
        imports = new ArrayList<String>();
        name = "";
        type = "";
        modifiers = new ArrayList<String>();
        extendees = new ArrayList<IModelItem>();
        members = new ArrayList<IMember>();
    }

    public List<IModelItem> getExtendees() {
        return extendees;
    }

    public void addExtendee(IModelItem extendee) {
        this.extendees.add(extendee);
    }

    public void setExtendees(final List<IModelItem> newExtendees) {
        this.extendees = newExtendees;
    }

    public String getIdentifier() {
        String result = "";
        if (namespace.length() > 0) {
            result += namespace + ".";
        }
        result += name;
        
        return result;
    }

    public String getName() {
        return name;
    }

    public List<String> getImports() {
        return imports;
    }
    
    public void addImport(String importStatement) {
        this.imports.add(importStatement);
    }
    
    public String getType() {
        return type;
    }

    public void setType(final String newType) {
        this.type = newType;
    }

    public List<IMember> getMembers() {
        return members;
    }

    public void addMember(final IMember newMember) {
        this.members.add(newMember);
    }

    public List<String> getModifiers() {
        return modifiers;
    }

    public void setModifiers(final List<String> newModifiers) {
        this.modifiers = newModifiers;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(final String newNamespace) {
        this.namespace = newNamespace;
    }
    
    public void setName(final String newName) {
        this.name = newName;
    }

    public boolean equals(final Object obj) {
        boolean result = false;
        if (!(obj instanceof ModelItem)) {
            return false;
        }
        IModelItem otherModelItem = (IModelItem) obj;

        boolean identifiersEqual = this.getIdentifier().equals(otherModelItem
                .getIdentifier());
        
        boolean typesEqual = this.type.equals(otherModelItem.getType());

        // Lists
        boolean modifiersContainsEqual = this.modifiers
                .containsAll(otherModelItem.getModifiers());
        boolean modifiersSizeEqual = (this.modifiers.size() == otherModelItem
                .getModifiers().size());
        boolean modifiersEqual = (modifiersContainsEqual && modifiersSizeEqual);

        boolean extendeesContainsEqual = this.extendees
                .containsAll(otherModelItem.getExtendees());
        boolean extendeesSizeEqual = (this.extendees.size() == otherModelItem
                .getExtendees().size());
        boolean extendeesEqual = (extendeesContainsEqual && extendeesSizeEqual);

        boolean membersContainsEqual = this.members.equals(otherModelItem
                .getMembers());
        boolean membersSizeEqual = (this.members.size() == otherModelItem
                .getMembers().size());
        boolean membersEqual = (membersContainsEqual && membersSizeEqual);

        result = (identifiersEqual && typesEqual && modifiersEqual 
                && extendeesEqual && membersEqual);

        return result;
    }

    public int hashCode() {
        int result = 7;
        result = 31 * result + (null == namespace ? 0 : namespace.hashCode());
        result = 31 * result + (null == imports ? 0 : imports.hashCode());
        result = 31 * result + (null == name ? 0 : name.hashCode());
        result = 31 * result + (null == type ? 0 : type.hashCode());
        result = 31 * result + (null == modifiers ? 0 : modifiers.hashCode());
        result = 31 * result + (null == extendees ? 0 : extendees.hashCode());
        result = 31 * result + (null == members ? 0 : members.hashCode());
        return result;
    }


    public String toString() {
        String tmpExtendees = "";
        for (IModelItem tmp : this.extendees) {
            tmpExtendees += tmp.getIdentifier() + ", ";
        }
        
        String importStatements = "";
        for (String tmpImport : this.imports) {
            importStatements += tmpImport + ", ";
        }
        
        if (!this.extendees.isEmpty()) {
            int tmpExtendeesLength = tmpExtendees.length(); 
            tmpExtendees = tmpExtendees.substring(0, (tmpExtendeesLength - 2));
        }

        return "\n" + "    Namespace : " + namespace + "\n"
                + "    Imports: " + importStatements + "\n"
                + "    Identifier: " + type + " " + this.getIdentifier() + "\n"
                + "    Modifiers : " + modifiers + "\n" + "    Extendee  : "
                + tmpExtendees + "\n" + "    Members   : " + members + "\n";
    }
}
