/*
 * JavaParser.java
 *
 * <Beschreibung>
 *
 * Created: Feb 15, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id: JavaParser.java 376 2007-06-01 22:27:39Z hinz_ja $
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.transformation.impl.java;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.logging.Logger;
import java5parsingCheckstyleGrammar.DetailAST;
import java5parsingCheckstyleGrammar.GeneratedJavaLexer;
import java5parsingCheckstyleGrammar.GeneratedJavaRecognizer;

import antlr.ASTFactory;
import antlr.RecognitionException;
import antlr.TokenStreamException;
import antlr.collections.AST;
import de.dlr.sistec.modi.transformation.IParser;

/**
 * This is a JavaParser example found somewhere on the web ... needs refactoring
 * 
 * @author someone else
 */
public class JavaParser implements IParser {

    private static final Logger LOGGER = Logger.getLogger("MoDiLogger");

    public JavaParser() {
    }

    public AST getAST(File file) {
        AST result = null;
        try {

            return parseFile(file);

        } catch (Exception e) {
            throw new Error("An Exception occurred during parsing \nfile: "
                    + file + "\nast:" + result + "\nexception: ", e);
        }

    }

    // Here's where we do the real work...
    private AST parseFile(File file) throws RecognitionException,
            FileNotFoundException {

        Reader reader = new BufferedReader(new FileReader(file));
        String filename = file.getName();
        AST result = new ASTFactory().create(0, filename);

        try {
            final GeneratedJavaLexer lexer = new GeneratedJavaLexer(reader);
            lexer.setFilename(filename);
            lexer.setCommentListener(null);
            lexer.setTreatAssertAsKeyword(true);
            lexer.setTreatEnumAsKeyword(true);

            final GeneratedJavaRecognizer parser = new GeneratedJavaRecognizer(
                    lexer);
            parser.setFilename(filename);
            parser.setASTNodeClass(DetailAST.class.getName());

            parser.compilationUnit(); // TokenStreamException if newline missing
            
            result.setFirstChild(parser.getAST());
            return result;

        } catch (TokenStreamException e) {
            LOGGER.info("/!\\ repairing a bad file (appending newline): "
                    + file);
            appendNewline(file);
            parseFile(file);
        }
        return result;
    }

    private void appendNewline(File file) {
        try {
            FileWriter appender = new FileWriter(file, true);
            appender.append('\n');
            appender.close();
        } catch (IOException e) {
            LOGGER.info("Could not repair file. An IOException occurred: \n"
                    + e.getMessage());
            System.exit(1);
        }
    }
}
