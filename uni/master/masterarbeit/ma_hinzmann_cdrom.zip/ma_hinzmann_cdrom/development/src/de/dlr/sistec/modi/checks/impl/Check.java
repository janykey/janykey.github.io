/*
 * ICheck.java
 *
 * <Beschreibung>
 *
 * Created: Mar 21, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.IDifference.Severity;

import de.dlr.sistec.modi.checks.ICheck;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IMetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;
import de.dlr.sistec.modi.metarepresentation.impl.MetaRepresentation;
import de.dlr.sistec.modi.metarepresentation.impl.Model;

/**
 * This abstract class provides a basis for Checsk. All Check should subclass 
 * Check and can use the methods provided here.
 * @author Jan Hinzmann
 */
public abstract class Check implements ICheck {

    private List<IModelElement> amModelElements;

    private List<IModelElement> dmModelElements;

    private String name;

    private Severity severity;

    protected Check() {
        amModelElements = new ArrayList<IModelElement>();
        dmModelElements = new ArrayList<IModelElement>();
        initLists();
    }

    public void setName(final String newName) {
        this.name = newName;
    }

    public String getName() {
        return this.name;
    }

    public void setSeverity(String newSeverity) {
        this.severity = Severity.valueOf(newSeverity);
    }

    public Severity getSeverity() {
        return severity;
    }

    /**
     * This method reduces the problemspace to interfaces only. That is, it goes
     * through the list of ModelItems and filters the  interfcaces. After 
     * calling this method thegetAMModelElements and getDMModelElements method
     * return only Lists of interfaces.<br/>
     * 
     * WARNING: /!\ What if one has to expand the problemspace again? /!\
     * Well that doesn't matter, as other checks get a fresh instance of their 
     * superclass (this one). There is only a problem, if you execute this check
     * over and over again.
     */
    //TODO refactor this: let it call reduceProblemSpaceTo("interface");
    protected void reduceProblemSpaceToInterfaces() {
        IMetaRepresentation metaRepresentation = MetaRepresentation
                .getInstance();
        
        amModelElements = new ArrayList<IModelElement>();
        List<IModelItem> amModelItems = metaRepresentation
                .getModelItems(Model.Type.AM);

        dmModelElements = new ArrayList<IModelElement>();
        List<IModelItem> dmModelItems = metaRepresentation
                .getModelItems(Model.Type.DM);

        /** reducing problem space to interfaces only */
        // get the interfaces from the architect's model
        for (IModelItem item : amModelItems) {
            if (item.getType().equals("interface")) {
                amModelElements.add((IModelElement) item);
            }
        }

        // get the interfaces from the developer's model
        for (IModelItem item : dmModelItems) {
            if (item.getType().equals("interface")) {
                dmModelElements.add((IModelElement) item);
            }
        }
    }

    protected void reduceProblemSpaceToClasses(){
        reduceProblemSpaceTo("class");
    }
    
    protected void reduceProblemSpaceTo(String modelItemType) {
        IMetaRepresentation metaRepresentation = MetaRepresentation
                .getInstance();
        
        amModelElements = new ArrayList<IModelElement>();
        List<IModelItem> amModelItems = metaRepresentation
                .getModelItems(Model.Type.AM);

        dmModelElements = new ArrayList<IModelElement>();
        List<IModelItem> dmModelItems = metaRepresentation
                .getModelItems(Model.Type.DM);

        /** reducing problem space to interfaces only */
        // get the interfaces from the architect's model
        for (IModelItem item : amModelItems) {
            if (item.getType().equals(modelItemType)) {
                amModelElements.add((IModelElement) item);
            }
        }

        // get the interfaces from the developer's model
        for (IModelItem item : dmModelItems) {
            if (item.getType().equals(modelItemType)) {
                dmModelElements.add((IModelElement) item);
            }
        }
    }
    
    protected void initLists() {
        IMetaRepresentation metaRepresentation = MetaRepresentation
                .getInstance();

        List<IModelItem> amModelItems = metaRepresentation
                .getModelItems(Model.Type.AM);

        List<IModelItem> dmModelItems = metaRepresentation
                .getModelItems(Model.Type.DM);

        for (IModelItem item : amModelItems) {
            amModelElements.add((IModelElement) item);
        }

        for (IModelItem item : dmModelItems) {
            dmModelElements.add((IModelElement) item);
        }
    }

    protected List<IModelElement> getAMModelElements() {
        // reduceProblemSpaceToInterfaces();
        return amModelElements;
    }

    protected List<IModelElement> getDMModelElements() {
        // reduceProblemSpaceToInterfaces();
        return dmModelElements;
    }
    
    protected List<IModelItem> getClasses(Model.Type type) {
        List<IModelItem> result = new ArrayList<IModelItem>();

        List<IModelItem> modelItems = MetaRepresentation.getInstance()
                .getModelItems(type);

        for (IModelItem item : modelItems) {
            if (item.getType().equals("class")) {
                result.add(item);
            }
        }

        return result;
    }
    
    protected List<IModelItem> getInterfaces(Model.Type type) {
        List<IModelItem> result = new ArrayList<IModelItem>();

        List<IModelItem> modelItems = MetaRepresentation.getInstance()
                .getModelItems(type);

        for (IModelItem item : modelItems) {
            if (item.getType().equals("interface")) {
                result.add(item);
            }
        }

        return result;
    }
    
    protected Map<IModelElement, IModelElement> getModifiedInterfaces(
            List<IDifference> differences) {
        
        return getModifiedModelItemsByType(differences, "interface");
        
    }

    
    protected Map<IModelElement, IModelElement> getModifiedClasses(
            List<IDifference> differences) {

        return getModifiedModelItemsByType(differences, "class");
        
    }
    
    protected Map<IModelElement, IModelElement> getModifiedModelItemsByType(
            List<IDifference> differences,String type) {
        Map<IModelElement, IModelElement> result 
            = new HashMap<IModelElement, IModelElement>();

        for (IDifference difference : differences) {
            if (difference.getLayer() == IDifference.Layer.MODELITEM) {
                
                IModelElement amItem = difference.getAMElement();
                IModelElement dmItem = difference.getDMElement();

                if (((IModelItem)amItem).getType().equals(type) 
                        && ((IModelItem)dmItem).getType().equals(type)) {
                    
                    result.put(amItem, dmItem);
                }
            }
        }

        return result;
    }
    
    protected List<IMember> getPublicOperations(IModelItem modelItem) {
        List<IMember> result = new ArrayList<IMember>();
        List<IMember> members = modelItem.getMembers();

        //interfaces may not have the pulic keyword
        if (modelItem.getType().equals("interface")) {
            for (IMember member : members) {
                if ((member instanceof IOperation)) {
                    result.add(member);
                }
            }
            return result;
        }
        
        for (IMember member : members) {
            if ((member instanceof IOperation) 
                    && member.getModifiers().contains("public")) {
                result.add(member);
            }
        }
        
        return result;
    }
    
    protected List<IMember> getPrivateOperations(IModelItem modelItem) {
        List<IMember> result = new ArrayList<IMember>();
        List<IMember> members = modelItem.getMembers();

        for (IMember member : members) {
            if ((member instanceof IOperation) 
                    && member.getModifiers().contains("private")) {
                result.add(member);
            }
        }
        
        return result;
    }

    protected List<IMember> getPrivateMember(IModelItem modelItem) {
        List<IMember> result = new ArrayList<IMember>();
        List<IMember> members = modelItem.getMembers();

        for (IMember member : members) {
            if (member.getModifiers().contains("private")) {
                result.add(member);
            }
        }
        
        return result;
    }
}
