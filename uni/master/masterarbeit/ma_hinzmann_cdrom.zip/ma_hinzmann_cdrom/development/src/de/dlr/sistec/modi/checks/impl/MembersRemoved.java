/*
 * MembersAdded.java
 *
 * <Beschreibung>
 *
 * Created: Feb 27, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $$Id: MembersAdded.java 187 2007-03-23 14:34:25Z hinz_ja $$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import de.dlr.sistec.modi.evaluation.IDifference;
import de.dlr.sistec.modi.evaluation.impl.Difference;
import de.dlr.sistec.modi.metarepresentation.IMember;
import de.dlr.sistec.modi.metarepresentation.IModelElement;
import de.dlr.sistec.modi.metarepresentation.IModelItem;
import de.dlr.sistec.modi.metarepresentation.IOperation;

/**
 * @author Jan Hinzmann
 * 
 */
public class MembersRemoved extends Check {

    /*
     * (non-Javadoc)
     * 
     * @see de.dlr.sistec.modi.checks.ICheck#check()
     */
    public List<IDifference> check(List<IDifference> currentDifferences) {
        List<IDifference> results = new ArrayList<IDifference>();

        Map<IModelElement, IModelElement> modifiedInterfaces 
            = getModifiedInterfaces(currentDifferences);

        for (IModelElement amElement : modifiedInterfaces.keySet()) {
            IModelElement dmElement = modifiedInterfaces.get(amElement);

            List<IMember> amMembers = ((IModelItem) amElement).getMembers();
            List<IMember> dmMembers = ((IModelItem) dmElement).getMembers();

            // compute the removed members
            List<IMember> removedMembers = new ArrayList<IMember>();
            removedMembers.addAll(amMembers);

            for (IMember member : dmMembers) {
                String dmIdentifier = member.getIdentifier();

                for (IMember removedMember : dmMembers) {
                    String amIdentifier = removedMember.getIdentifier();

                    if (dmIdentifier.equals(amIdentifier)) {
                        removedMembers.remove(removedMember);
                    }
                }
            }
            // now we have the removed members for this interface

            for (IMember member : removedMembers) {
                String memberType = "member";
                if (member instanceof IOperation) {
                    memberType = "operation";
                } else {
                    memberType = "variable";
                }
                
                IDifference difference = new Difference();
                difference.setName(super.getName());
                difference.setSeverity(super.getSeverity());
                difference.setDescription("The " + memberType + "\"" 
                        + member.getIdentifier() 
                        + "\" has been removed from the interface \""
                        + modifiedInterfaces.get(amElement).getIdentifier() 
                        + "\".");
                difference.setLayer(IDifference.Layer.MEMBER);
                difference.setStatus(IDifference.Status.REMOVED);
                difference.setParentElement(modifiedInterfaces.get(amElement));
                difference.setAMElement((IModelElement) member);
                results.add(difference);
            }

        }
        return results;
    }

}
