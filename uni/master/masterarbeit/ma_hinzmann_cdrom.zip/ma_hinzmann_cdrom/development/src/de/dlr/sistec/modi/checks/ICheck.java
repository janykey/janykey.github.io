/*
 * ICheck.java
 *
 * <Beschreibung>
 *
 * Created: Mar 21, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $Id$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */
package de.dlr.sistec.modi.checks;

import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference.Severity;

import de.dlr.sistec.modi.evaluation.IDifference;

/**
 * @author Jan Hinzmann
 *
 */
public interface ICheck {

    void setName(final String name);
    String getName();
    
    void setSeverity(final String severity);
    Severity getSeverity();
    
    List<IDifference> check(List<IDifference> currentDifferences);

}
