/*
 * InterfacesAdded.java
 *
 * <Beschreibung>
 *
 * Created: Feb 13, 2007 Jan Hinzmann <jan-oliver.hinzmann@dlr.de>
 * Changed:
 *
 * $$Id: InterfacesAdded.java 187 2007-03-23 14:34:25Z hinz_ja $$
 *
 * Copyright (C) 2007 DLR SC, Germany
 *
 * All rights reserved
 *
 * http://www.dlr.de/sc
 */

package de.dlr.sistec.modi.checks.impl;

import java.util.List;

import de.dlr.sistec.modi.evaluation.IDifference;

/**
 * @author Jan Hinzmann
 * 
 */
public class InterfacesAdded extends ModelItemsAdded {


    /**
     * Checks for Interfaces added to the Model. That is, an Interface is in the
     * list of interfaces in the developers model (DM) but not in the list of 
     * the interfaces in the architects model (AM).
     * Therefore all interfaces in the DM are suspicious and copied to the list
     * of added interfaces. 
     * Then the interfaces found also to be in the DM and in the AM are removed
     * from the list of suspicious interfaces leaving the added interfaces in 
     * the list. 
     */
    @Override
    public List<IDifference> check(List<IDifference> currentDifferences) {
        super.reduceProblemSpaceToInterfaces();
        return super.check(currentDifferences);
    }

}
