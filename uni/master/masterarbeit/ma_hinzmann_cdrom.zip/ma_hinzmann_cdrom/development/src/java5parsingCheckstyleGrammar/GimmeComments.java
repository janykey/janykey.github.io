/**
 * Copyright (C) 2007 DLR/SISTEC, Germany 
 * All rights reserved 
 * filename GimmeComments.java
 * @author Jan Hinzmann Mar 14, 2007
 * @version $Id$
 */
package java5parsingCheckstyleGrammar;

/**
 * This is a comment listener which can report comments. The two methods are 
 * called during the lexing step.
 * @author Jan Hinzmann
 *
 */
public class GimmeComments implements CommentListener {

	/* (non-Javadoc)
	 * @see checkstyleGrammar.CommentListener#reportBlockComment(java.lang.String, int, int, int, int)
	 */
	public void reportBlockComment(String aType, int aStartLineNo,
			int aStartColNo, int aEndLineNo, int aEndColNo) {
		// TODO Auto-generated method stub
//		System.out.println("type: " + aType + " line: " + aStartLineNo + 
//				" col: " + aStartColNo + " endline: " + aEndLineNo + " endcol: "
//				+ aEndColNo);

	}

	/* (non-Javadoc)
	 * @see checkstyleGrammar.CommentListener#reportSingleLineComment(java.lang.String, int, int)
	 */
	public void reportSingleLineComment(String aType, int aStartLineNo,
			int aStartColNo) {
		// TODO Auto-generated method stub
//		System.out.println("type: " + aType + " line: " + aStartLineNo);

	}

}
