public interface AnInterface {

	void myMethod();

}
