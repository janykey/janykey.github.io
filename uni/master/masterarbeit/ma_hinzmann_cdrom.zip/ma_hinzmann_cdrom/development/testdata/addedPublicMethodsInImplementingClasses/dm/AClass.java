public class AClass implements AnInterface {

	public void myMethod(){
	}
	
	/**
	 * This is a public method added to this class which is not in defined in 
	 * the interface. This should be found by the check 
	 * AddedPublicMethodsInImplementingClasses
	 */
	public void addedMethod(){
	}
        
        public String toString(){return "";}
}
