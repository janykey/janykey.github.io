public class BClass implements AnInterface {

	public void myMethod(){
	}
	
}
