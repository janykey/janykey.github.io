public interface AnInterface {

	void myMethod();

        void foo();
}
