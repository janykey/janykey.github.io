/**
 * @author Jan Hinzmann
 *
 */
public class BadClass {

	/*
	 * a one line comment after the class definition does not work
	 */
}

// change log
