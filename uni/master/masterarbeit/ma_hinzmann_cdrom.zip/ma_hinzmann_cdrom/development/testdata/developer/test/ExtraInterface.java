/**
 * Copyright (C) 2007 DLR/SISTEC, Germany 
 * All rights reserved 
 * filename ExtraInterface.java
 * @author Jan Hinzmann Feb 27, 2007
 * @version $Id: ExtraInterface.java 174 2007-03-21 09:51:46Z hinz_ja $
 */
package test;

/**
 * @author Jan Hinzmann
 *
 */
public interface ExtraInterface {

}
