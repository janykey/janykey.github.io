import java.util.*;
public interface AnotherInterface {
    
    //this has been added
    
}
