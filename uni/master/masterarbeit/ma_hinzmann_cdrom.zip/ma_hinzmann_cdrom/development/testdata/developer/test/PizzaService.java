package test;

import java.util.Date;

/**
 * only "public" and "abstract" are permitted
 * 
 * @author jan
 * 
 */
public abstract interface PizzaService extends Service {

    // ---- protocol ----------------------------------------------------------
    /*
     * first you should call your favorite pizzaservice. you then set the size
     * of your pizza, continue with setting the desired toppings, finally set
     * the address the pizza should be delivered to. Then you can ask for time
     * it will take until the pizza is delivered.
     */

    // ---- constants ----------------------------------------------------------
    /**
     * only public static final are permitted
     */
    public enum Size {
        SMALL, MEDIUM, BIG, SUPERSIZED
    };

    public enum Toppings {
        TOMATATOES, PEPPER, MUSHROOMS, SALAMI
    };

    // ---- methods ------------------------------------------------------------
    /**
     * only public abstract are permitted
     */
    void callForPizza();

    void setSize(int size);

    void setToppings(int[] toppings);

    void setAddress(Address address);

    Date finalizeOrder();

}