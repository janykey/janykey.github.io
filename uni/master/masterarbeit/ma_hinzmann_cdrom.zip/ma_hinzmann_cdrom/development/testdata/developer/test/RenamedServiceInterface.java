/**
 * Copyright (C) 2007 DLR/SISTEC, Germany 
 * All rights reserved 
 * filename Service.java
 * @author Jan Hinzmann Feb 16, 2007
 * @version $Id: RenamedServiceInterface.java 174 2007-03-21 09:51:46Z hinz_ja $
 */
package test;

import java.util.Date;

/**
 * @author Jan Hinzmann
 *
 */
public interface RenamedServiceInterface {
//	public static final String StringCONSTANT = "Hello World!";
//	int IntCONSTANT;
//	void foo(int i, int j, int k);
//	void foo();
//	public static Object doAnything(Object o) throws Exception;
	
//	class FOO{ int i;}
//	interface bar{}
}