package test;
/**
 * This is a developers interface. It 
 * has been slightly modified! or not?
 */
public interface AnInterface {

    int letMeAlone;
   
    //int removeMe;
    
    int thisIsAdded;
    
    int modifyMe = 1;
    
    void stay(int i);
    void added();
    //void remove();
    void modified(int i);
    
}
