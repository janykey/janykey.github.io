package test;

import java.util.Date;

import test.Address;


public class Joeys implements PizzaService {

	public void callForPizza() {
		// TODO Auto-generated method stub
		
	}

	public Date finalizeOrder() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setAddress(Address address) {
		// TODO Auto-generated method stub
		
	}

	public void setSize(int size) {
		// TODO Auto-generated method stub
		
	}

	public void setToppings(int[] toppings) {
		// TODO Auto-generated method stub
		
	}
	
	public String getTelephonenumber(String s, int i) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object doAnything(Object o) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
