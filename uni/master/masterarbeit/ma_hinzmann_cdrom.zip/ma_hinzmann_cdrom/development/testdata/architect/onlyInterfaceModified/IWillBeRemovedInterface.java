package test;
/**
 * This interface will be removed by the developer.
 */
public interface IWillBeRemovedInterface {
    
}