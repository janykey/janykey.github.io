/**
 * Copyright (C) 2007 DLR/SISTEC, Germany 
 * All rights reserved 
 * filename Service.java
 * @author Jan Hinzmann Feb 16, 2007
 * @version $Id: Service.java 175 2007-03-21 09:52:06Z hinz_ja $
 */
package test;

/**
 * @author Jan Hinzmann
 *
 */
public interface Service {

}
