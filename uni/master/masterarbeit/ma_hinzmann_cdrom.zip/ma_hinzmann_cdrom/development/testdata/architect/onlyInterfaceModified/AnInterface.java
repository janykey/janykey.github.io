package test;
/**
 * This is the original interface 
 * specified by the architect.
 */
public interface AnInterface {

    int letMeAlone;
    
    int removeMe;
    
    //int thisIsAdded;
    
    int modifyMe = 0;
    
    void stay(int i);
    //void added();
    void remove();
    void modified();

}
