
public class ImplementsALot implements Foo, Bar, List, Blubb {
    
    
}