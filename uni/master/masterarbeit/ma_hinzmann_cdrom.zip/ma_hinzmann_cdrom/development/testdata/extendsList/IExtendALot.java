
public interface IExtendALot extends Foo, Bar, List, Blubb {
    
    
}