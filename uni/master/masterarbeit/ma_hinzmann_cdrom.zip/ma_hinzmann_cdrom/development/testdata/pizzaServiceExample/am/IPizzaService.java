package de.hinzmann.service.pizza;

/**
 * This is the original interface from the architect
 * 
 * @author Jan Hinzmann
 */
public interface IPizzaService {
    

    // Protocoll
    /*
     * first call your pizzaservice. then set the size of your pizza, continue
     * with setting the desired toppings, set the address the pizza should be
     * delivered to. finally ask for the length of time until the pizza will be
     * delivered.
     * 
     */
    
    // constants
    public static final enum Size {SMALL, MEDIUM, BIG};
    public static final enum Toppings {TOMATOES, PEPPER, MUSHROOMS};

    // methods
    public abstract void callForPizza(ICaller caller);
    public abstract void setSize(Size size);
    public abstract void setToppings(Toppings[] toppings);
    public abstract void setAddress(IAddress address);
    public abstract Date finalizeOrder();

}