package de.hinzmann.service.pizza;

/**
 * This is the interfcae modified by the developers.
 * The setAddress(IAddress address) method has been removed.
 * BECAUSE the address can be obtained from the ICaller.
 * 
 * @author TheTeam
 */
public interface IPizzaService {


    // Protocoll
    /*
     * first call your pizzaservice.
     * then set the size of your pizza,
     * continue with setting the desired toppings,
     * set the address the pizza should be delivered to.
     * finally ask for the length of time until the pizza will be delivered.
     * 
     */

    //constants
    public static final enum Size {SMALL, MEDIUM, BIG};
    public static final enum Toppings {TOMATOES, PEPPER, MUSHROOMS};

    //methods
    public abstract void callForPizza(ICaller caller);
    public abstract void setSize(Size size);
    public abstract void setToppings(Toppings[] toppings);
    public abstract Date finalizeOrder();

}