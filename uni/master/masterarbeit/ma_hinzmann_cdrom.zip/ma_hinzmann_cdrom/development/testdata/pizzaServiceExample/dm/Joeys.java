package de.hinzmann.service.pizza;

import IPizzaService.Size;
import IPizzaService.Toppings;

/**
 * This is an additional class. This should result in a difference with
 * the severity LOW.
 * 
 * @author TheTeam
 */
public class Joeys implements IPizzaService {


    //methods
    public abstract void callForPizza(ICaller caller){/*really lazy*/}
    public abstract void setSize(Size size){/*really lazy*/}
    public abstract void setToppings(Toppings[] toppings){/*really lazy*/}
    public abstract Date finalizeOrder(){/*really lazy*/return null;}

}