importPackage(Packages.java.io);

////////////////////////////////////////////////////////////////////////////////
// PREFERENCES
// fill in the installation specific properties here
////////////////////////////////////////////////////////////////////////////////

/**
 * Version
 */
var VERSION = "cocoonWebservice v0.1";



////////////////////////////////////////////////////////////////////////////////
// Webservice 
////////////////////////////////////////////////////////////////////////////////

/**
 * This function is for the webservice, it is called, when a SOAP-Envelope is 
 * received, gets the Parameters out of it and then dispatches the called method to 
 * javaclasses in the package jan.
 * Then it finally generates a SOAP-response and serialises it back to the client.
 */
function cocoonWS(){

	
	//getting the envelope out of the request (can be done only once)
	var soapEnvelope = new java.io.ByteArrayOutputStream();
	cocoon.processPipelineTo("soapEnvelope", null, soapEnvelope);
	clog("Request was:\n" + soapEnvelope + "\n");
	

	//enabling the jxtemplate
	cocoon.session.setAttribute( "saxer", stringToSAX  );

	//getting the method out of the soap-content (stored in 'soapData')
	var soapMethod   = new java.io.ByteArrayOutputStream();	
	cocoon.processPipelineTo("soap",
			{"soapData":soapEnvelope, "stylesheet":"soapMethod"}, soapMethod);	
	clog("soapMethod is: " + soapMethod + "\n");
	

    /*
     * Now that we have the method, we generate the according parameters and 
     * execute the code for the called method	
     */
	if(soapMethod == "echo"){
		clog("echo called");

        //generate the parameter
        var soapParameter = new java.io.ByteArrayOutputStream();        
        
        cocoon.processPipelineTo("soap",
        	{"soapData":soapEnvelope, "stylesheet":"soapEcho"}, soapParameter);
        clog("soapParameter: " + soapParameter);
                
        //process the method (echo in this case)
		/*
		 * Here we compute something e.g. some businessprocess
		 * can be executed (sendMail, ftpUpload,...)
		 * for the echo Method it would be:
		 * //var answer = parameter;
		 * but we put this right in the answer.
		 */

        //send the answer
        cocoon.sendPage("soapAnswer", {"answer":soapParameter});

        clog("done.");
        return;

	} else if (soapMethod == "version"){
		clog("verison called");

		//generate the parameter
		/* no parameter to generate */

		//process the method
        var answer = VERSION;

		//send the answer
        cocoon.sendPage("soapAnswer", {"answer":answer});

		clog("done.");
        return;

	} else { /* here you can add more methods */

	    //setting the answer if no method matched
	    //TODO in this case we should generate a SOAP-FAULT
	    var answer = "The method you have called is not understood by this server. " +
					"Sorry!";         
		cocoon.sendPage("soapAnswer", {"answer":answer});
		clog("no method matched, sending error-statment");
	    return;
    }
}



////////////////////////////////////////////////////////////////////////////////
// ------------------ JXHelpermethod------------------------------------------//
////////////////////////////////////////////////////////////////////////////////

/**
 * function from joose: http://joose.iki.fi/cocoon/saxInJX.txt
 */
function stringToSAX( str, consumer, ignoreRootElement ) {
        var is = new Packages.org.xml.sax.InputSource( new java.io.StringReader( str ) );
        var ignore = ( ignoreRootElement == "true" );
        var parser = null;
        var includeConsumer = new org.apache.cocoon.xml.IncludeXMLConsumer(consumer, consumer );
        
        includeConsumer.setIgnoreRootElement( ignore );
        
        try {   
                parser = cocoon.getComponent(Packages.org.apache.excalibur.xml.sax.SAXParser.ROLE );
                parser.parse( is, includeConsumer );    
        } finally {
                if ( parser != null ) cocoon.releaseComponent( parser );
        }
}


////////////////////////////////////////////////////////////////////////////////
// ------------------ Logging ------------------------------------------------//
////////////////////////////////////////////////////////////////////////////////

/**
 * logs the given String with a timestamp to <cocoonDir>/WEB-INF/logs/flow.log
 */
function log(logString){
        cocoon.log.info(logString);
}

/**
 * Console Logging aka consoleDebugging
 * if tomcat is used entriesare found in
 * $CATALINAHOME/logs/catalina.log
 */
function clog(logString){
        print(logString);
}

